"""Private, staff-bound management UI for configured scrims."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import discord
from discord.ext import commands

from global_setup import extract_raw_emoji
from slot_storage import SlotStorageError
from scrim_state import (
    DEFAULT_IDPW_TIMEZONE,
    DEFAULT_SLOT_END,
    DEFAULT_SLOT_START,
    IDPW_TIMEZONE_CHOICES,
    validate_slot_range,
)


logger = logging.getLogger(__name__)


async def _delete_command_message(ctx: commands.Context) -> None:
    message = getattr(ctx, "message", None)
    delete = getattr(message, "delete", None)
    if delete is None:
        return
    try:
        await delete()
    except (discord.NotFound, discord.Forbidden, discord.HTTPException):
        pass


def _safe_name(value: str) -> str:
    return discord.utils.escape_mentions(discord.utils.escape_markdown(value))


def _short_name(value: str, limit: int = 20) -> str:
    return (
        _safe_name(value).replace("\r", " ").replace("\n", " ")[:limit].rstrip("\\")
    )


def _channel_ref(channel_id: int | None) -> str:
    return f"<#{channel_id}>" if channel_id else "not configured"


def _role_ref(role_id: int | None) -> str:
    return f"<@&{role_id}>" if role_id else "not configured"


def _scrim_configuration_details(scrim) -> str:
    return (
        f"Name: **{_safe_name(scrim.name)}**\n"
        f"Public channel: {_channel_ref(scrim.public_channel_id)}\n"
        f"Staff channel: {_channel_ref(scrim.staff_channel_id)}\n"
        f"Captain management channel: {_channel_ref(scrim.cap_channel_id)}\n"
        f"Logs channel: {_channel_ref(scrim.logs_channel_id)}\n"
        f"History channel: {_channel_ref(scrim.history_channel_id)}\n"
        f"Staff role: {_role_ref(scrim.staff_role_id)}\n"
        f"**Pending Captain Role:** {_role_ref(scrim.pending_role_id)}\n"
        f"**Confirmed Captain Role:** {_role_ref(scrim.confirmed_role_id)}\n"
        f"Slots: {scrim.slot_start:02d}–{scrim.slot_end:02d}"
    )


def _slot_range_from_count(start_value: object, count_value: object) -> tuple[int, int]:
    try:
        start = int(str(start_value).strip())
        count = int(str(count_value).strip())
    except (TypeError, ValueError) as error:
        raise ValueError(
            "The first slot and number of slots must be whole numbers."
        ) from error
    if count < 1:
        raise ValueError("The number of slots must be at least 1.")
    end = start + count - 1
    validate_slot_range(start, end)
    return start, end


def _interaction_is_authorized(
    interaction: discord.Interaction, owner_id: int, guild_id: int
) -> bool:
    guild = interaction.guild
    user = interaction.user
    permissions = getattr(user, "guild_permissions", None)
    return (
        guild is not None
        and guild.id == guild_id
        and user.id == owner_id
        and permissions is not None
        and getattr(permissions, "administrator", False)
    )


async def _deny(interaction: discord.Interaction) -> None:
    text = (
        "This setup control belongs to the staff member who opened it. "
        "Run `!setup` yourself if you have the configured Staff role."
    )
    if interaction.response.is_done():
        await interaction.followup.send(text, ephemeral=True)
    else:
        await interaction.response.send_message(text, ephemeral=True)


async def _send_error(interaction: discord.Interaction, error: Exception) -> None:
    logger.exception("Setup interaction failed", exc_info=error)
    if isinstance(error, SlotStorageError):
        text = "The change could not be saved. Nothing was changed. Please try again."
    else:
        text = "Something went wrong. Please try again."
    try:
        if interaction.response.is_done():
            await interaction.followup.send(text, ephemeral=True)
        else:
            await interaction.response.send_message(text, ephemeral=True)
    except discord.HTTPException:
        logger.exception("Could not report a setup interaction error")


def _channel_permissions_error(
    guild: discord.Guild,
    public_channel: discord.TextChannel,
    staff_channel: discord.TextChannel,
    *extra_channels: tuple[discord.TextChannel, str],
) -> str | None:
    member = guild.me
    if member is None:
        return "I could not determine my server permissions. Please try again."

    required = ("view_channel", "send_messages", "read_message_history")
    for channel, label in (
        (public_channel, "public"),
        (staff_channel, "staff"),
        *extra_channels,
    ):
        permissions = channel.permissions_for(member)
        missing = [
            permission.replace("_", " ").title()
            for permission in required
            if not getattr(permissions, permission, False)
        ]
        if missing:
            return (
                f"I am missing {', '.join(missing)} in the {label} channel "
                f"{channel.mention}."
            )

    if not public_channel.permissions_for(member).manage_messages:
        return (
            f"I need Manage Messages in the public channel {public_channel.mention} "
            "so processed `!add` messages can be deleted."
        )
    return None


def install_setup(bot, repository, publish_scrim, log_action=None) -> None:
    """Install the guild-only ``!setup`` command on *bot*."""

    def setup_authorized(
        interaction: discord.Interaction, owner_id: int, guild_id: int
    ) -> bool:
        if (
            interaction.guild is None
            or interaction.guild.id != guild_id
            or interaction.user.id != owner_id
            or not repository.is_guild_authorized(guild_id)
        ):
            return False
        config = repository.get_server_config(guild_id)
        return bool(
            config
            and config.staff_role_id is not None
            and config.staff_role_id in {
                getattr(role, "id", None)
                for role in getattr(interaction.user, "roles", ())
            }
        )

    def user_is_staff(user: object, guild_id: int) -> bool:
        config = repository.get_server_config(guild_id)
        return bool(
            config
            and config.staff_role_id is not None
            and config.staff_role_id in {
                getattr(role, "id", None) for role in getattr(user, "roles", ())
            }
        )

    async def retire_message(
        guild: discord.Guild,
        channel_id: int | None,
        message_id: int | None,
        runtime_message: object | None,
    ) -> None:
        if channel_id is None or message_id is None:
            return
        message = runtime_message
        try:
            if message is None:
                channel = guild.get_channel(channel_id)
                if isinstance(channel, discord.TextChannel):
                    message = await channel.fetch_message(message_id)
            if message is not None:
                await message.edit(view=None)
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            logger.exception("Could not retire an old scrim board message")

    async def apply_scrim_change(
        interaction: discord.Interaction,
        panel: "SetupPanel",
        scrim_id: str,
        *,
        changes: dict[str, object],
        response_mode: str = "deferred",
    ) -> None:
        if response_mode == "modal":
            await interaction.response.defer(ephemeral=True)
        scrim = repository.get(scrim_id)
        if scrim is None or scrim.guild_id != panel.guild_id:
            text = "That scrim no longer exists."
            if response_mode == "modal":
                await interaction.edit_original_response(content=text, view=None)
            else:
                await interaction.edit_original_response(content=text, view=None)
            await panel.refresh_message()
            return

        old = {
            "name": scrim.name,
            "public_channel_id": scrim.public_channel_id,
            "staff_channel_id": scrim.staff_channel_id,
            "staff_role_id": scrim.staff_role_id,
            "pending_role_id": scrim.pending_role_id,
            "confirmed_role_id": scrim.confirmed_role_id,
            "cap_channel_id": scrim.cap_channel_id,
            "logs_channel_id": scrim.logs_channel_id,
            "history_channel_id": scrim.history_channel_id,
            "slot_start": scrim.slot_start,
            "slot_end": scrim.slot_end,
            "public_message_id": scrim.public_message_id,
            "staff_message_id": scrim.staff_message_id,
            "runtime_message": scrim.runtime_message,
            "runtime_staff_message": scrim.runtime_staff_message,
        }
        values = {
            "name": scrim.name,
            "public_channel_id": scrim.public_channel_id,
            "staff_channel_id": scrim.staff_channel_id,
            "staff_role_id": scrim.staff_role_id,
            "pending_role_id": scrim.pending_role_id,
            "confirmed_role_id": scrim.confirmed_role_id,
            "cap_channel_id": scrim.cap_channel_id,
            "logs_channel_id": scrim.logs_channel_id,
            "history_channel_id": scrim.history_channel_id,
            "slot_start": scrim.slot_start,
            "slot_end": scrim.slot_end,
        }
        values.update(changes)
        try:
            updated = repository.update_scrim(
                scrim_id,
                panel.guild_id,
                **values,
            )
        except (SlotStorageError, ValueError) as error:
            text = (
                "The change could not be saved. "
                f"{error}"
            )
            if response_mode == "modal":
                await interaction.edit_original_response(
                    content=text,
                    view=ScrimEditView(panel, panel.owner_id, panel.guild_id, scrim_id),
                )
            else:
                await interaction.edit_original_response(
                    content=text,
                    view=ScrimEditView(panel, panel.owner_id, panel.guild_id, scrim_id),
                )
            return

        public_changed = old["public_channel_id"] != updated.public_channel_id
        staff_changed = old["staff_channel_id"] != updated.staff_channel_id
        if public_changed or staff_changed:
            with repository.transaction():
                if public_changed:
                    updated.public_message_id = None
                    updated.runtime_message = None
                if staff_changed:
                    updated.staff_message_id = None
                    updated.runtime_staff_message = None

        if public_changed:
            await retire_message(
                interaction.guild,
                old["public_channel_id"],
                old["public_message_id"],
                old["runtime_message"],
            )
        if staff_changed:
            await retire_message(
                interaction.guild,
                old["staff_channel_id"],
                old["staff_message_id"],
                old["runtime_staff_message"],
            )

        board_refreshed = True
        if (
            old["name"] != updated.name
            or public_changed
            or staff_changed
            or old["slot_start"] != updated.slot_start
            or old["slot_end"] != updated.slot_end
        ):
            try:
                board_refreshed = await publish_scrim(updated)
            except Exception as error:
                logger.exception("Could not refresh the edited scrim", exc_info=error)
                board_refreshed = False

        await panel.refresh_message()
        def format_value(field: str, value: object) -> str:
            if field.endswith("channel_id"):
                return f"<#{value}>"
            if field.endswith("role_id"):
                return f"<@&{value}>"
            return _safe_name(str(value))

        changed_fields = ", ".join(changes)
        details = "Changed: " + ", ".join(
            f"{field}: {format_value(field, old[field])} → "
            f"{format_value(field, changes[field])}"
            for field in changes
        ) + "."
        if not board_refreshed:
            details += " The slot boards could not be refreshed."
        if log_action is not None:
            try:
                await log_action(updated, "SCRIM CONFIGURATION UPDATED", details)
            except Exception:
                logger.exception("Could not write scrim configuration log")

        text = (
            f"✅ **{_safe_name(updated.name)}** was updated.\n"
            f"Changed: {changed_fields}."
        )
        if not board_refreshed:
            text += " The saved configuration is active, but the slot boards need a refresh."
        edit_view = ScrimEditView(
            panel, panel.owner_id, panel.guild_id, scrim_id
        )
        if response_mode == "modal":
            await interaction.edit_original_response(
                content=text,
                view=edit_view,
            )
        else:
            await interaction.edit_original_response(
                content=text,
                view=edit_view,
            )

    class BoundView(discord.ui.View):
        def __init__(self, owner_id: int, guild_id: int, *, timeout: float = 900):
            super().__init__(timeout=timeout)
            self.owner_id = owner_id
            self.guild_id = guild_id

        async def interaction_check(self, interaction: discord.Interaction) -> bool:
            if not setup_authorized(
                interaction, self.owner_id, self.guild_id
            ):
                await _deny(interaction)
                return False
            return True

        async def on_error(
            self,
            interaction: discord.Interaction,
            error: Exception,
            item: discord.ui.Item[Any],
        ) -> None:
            await _send_error(interaction, error)

    class SetupPanel(BoundView):
        def __init__(self, owner_id: int, guild_id: int):
            super().__init__(owner_id, guild_id)
            self.selected_id: str | None = None
            self.message: discord.Message | None = None
            self.scrims: list[Any] = []
            self.rebuild()

        def load_scrims(self) -> list[Any]:
            self.scrims = list(repository.list(self.guild_id))
            if self.selected_id is not None and not any(
                scrim.id == self.selected_id for scrim in self.scrims
            ):
                self.selected_id = None
            return self.scrims

        def content(self) -> str:
            if not self.scrims:
                return (
                    "**Scrim setup**\n"
                    "No scrims are configured for this server. Select **Add scrim** "
                    "to configure one using existing text channels.\n\n"
                    "ID/PW: configure it after selecting a scrim."
                )
            lines = ["**Scrim setup**", "Configured scrims:"]
            for scrim in self.scrims:
                marker = "▶ " if scrim.id == self.selected_id else "• "
                state = "OPEN" if scrim.is_open else "CLOSED"
                pending_role = (
                    f"<@&{scrim.pending_role_id}>"
                    if scrim.pending_role_id
                    else "not configured"
                )
                confirmed_role = (
                    f"<@&{scrim.confirmed_role_id}>"
                    if scrim.confirmed_role_id
                    else "not configured"
                )
                idpw = repository.get_idpw_config(scrim.id)
                idpw_status = (
                    f"ID/PW <#{idpw.target_channel_id}> configured"
                    if idpw is not None
                    else "ID/PW not configured"
                )
                lines.append(
                    f"{marker}**{_short_name(scrim.name)}** [{state}] "
                    f"public {_channel_ref(scrim.public_channel_id)} · "
                    f"staff {_channel_ref(scrim.staff_channel_id)} · "
                    f"!cap {_channel_ref(scrim.cap_channel_id)} · "
                    f"Pending Captain Role {pending_role} · "
                    f"Confirmed Captain Role {confirmed_role} · "
                    f"logs {_channel_ref(scrim.logs_channel_id)} · "
                    f"history {_channel_ref(scrim.history_channel_id)} · "
                    f"slots {scrim.slot_start:02d}–{scrim.slot_end:02d} · "
                    f"{idpw_status}"
                )
            lines.append(
                "\nChoose a scrim to show/refresh its board, edit its configuration, "
                "configure ID/PW, or delete it. Use `!open` and `!close` in the "
                "public slots channel."
            )
            return "\n".join(lines)

        def rebuild(self) -> None:
            self.clear_items()
            self.load_scrims()
            if self.scrims:
                select = discord.ui.Select(
                    placeholder="Choose a configured scrim",
                    min_values=1,
                    max_values=1,
                    options=[
                        discord.SelectOption(
                            label=scrim.name[:100],
                            value=scrim.id,
                            description=(
                                f"Public #{scrim.public_channel_id} · "
                                f"Staff #{scrim.staff_channel_id}"
                            )[:100],
                            default=scrim.id == self.selected_id,
                        )
                        for scrim in self.scrims[:25]
                    ],
                    row=0,
                )

                async def select_callback(interaction: discord.Interaction) -> None:
                    if not await self.interaction_check(interaction):
                        return
                    selected_id = select.values[0]
                    selected = repository.get(selected_id)
                    if selected is None or selected.guild_id != self.guild_id:
                        self.selected_id = None
                        self.rebuild()
                        await interaction.response.edit_message(
                            content=(
                                "That scrim no longer exists.\n\n" + self.content()
                            ),
                            view=self,
                        )
                        return
                    self.selected_id = selected.id
                    self.rebuild()
                    await interaction.response.edit_message(
                        content=self.content(), view=self
                    )

                select.callback = select_callback
                self.add_item(select)

            add_button = discord.ui.Button(
                label="Add scrim",
                style=discord.ButtonStyle.success,
                row=1,
            )

            async def add_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                await interaction.response.send_modal(
                    ScrimNameModal(self, self.owner_id, self.guild_id)
                )

            add_button.callback = add_callback
            self.add_item(add_button)

            show_button = discord.ui.Button(
                label="Show/refresh slots",
                style=discord.ButtonStyle.primary,
                disabled=self.selected_id is None,
                row=1,
            )

            async def show_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                scrim = (
                    repository.get(self.selected_id)
                    if self.selected_id is not None
                    else None
                )
                if scrim is None or scrim.guild_id != self.guild_id:
                    self.selected_id = None
                    self.rebuild()
                    await interaction.response.edit_message(
                        content="That scrim no longer exists.\n\n" + self.content(),
                        view=self,
                    )
                    return
                await interaction.response.defer(ephemeral=True)
                try:
                    published = await publish_scrim(scrim)
                except Exception as error:
                    logger.exception("Could not publish scrim board", exc_info=error)
                    published = False
                if published:
                    text = (
                        f"The slot board for **{_safe_name(scrim.name)}** was "
                        f"published or refreshed in <#{scrim.public_channel_id}>."
                    )
                else:
                    text = (
                        f"The slot board for **{_safe_name(scrim.name)}** could not "
                        f"be published in <#{scrim.public_channel_id}>. Check the "
                        "channel and my permissions, then try again."
                    )
                await interaction.followup.send(text, ephemeral=True)

            show_button.callback = show_callback
            self.add_item(show_button)

            delete_button = discord.ui.Button(
                label="Delete scrim",
                style=discord.ButtonStyle.danger,
                disabled=self.selected_id is None,
                row=1,
            )

            async def delete_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                scrim = (
                    repository.get(self.selected_id)
                    if self.selected_id is not None
                    else None
                )
                if scrim is None or scrim.guild_id != self.guild_id:
                    self.selected_id = None
                    self.rebuild()
                    await interaction.response.edit_message(
                        content="That scrim no longer exists.\n\n" + self.content(),
                        view=self,
                    )
                    return
                await interaction.response.send_message(
                    f"Delete **{_safe_name(scrim.name)}**? This permanently removes "
                    "its saved slot data, but does not delete either Discord channel.",
                    view=DeleteConfirmation(
                        self, self.owner_id, self.guild_id, scrim.id
                    ),
                    ephemeral=True,
                )

            delete_button.callback = delete_callback
            self.add_item(delete_button)

            edit_button = discord.ui.Button(
                label="Edit",
                emoji="✏️",
                style=discord.ButtonStyle.secondary,
                disabled=self.selected_id is None,
                row=2,
            )

            async def edit_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                scrim = (
                    repository.get(self.selected_id)
                    if self.selected_id is not None
                    else None
                )
                if scrim is None or scrim.guild_id != self.guild_id:
                    self.selected_id = None
                    self.rebuild()
                    await interaction.response.edit_message(
                        content="That scrim no longer exists.\n\n" + self.content(),
                        view=self,
                    )
                    return
                await interaction.response.send_message(
                    ScrimEditView.content(scrim),
                    view=ScrimEditView(
                        self, self.owner_id, self.guild_id, scrim.id
                    ),
                    ephemeral=True,
                    allowed_mentions=discord.AllowedMentions.none(),
                )

            edit_button.callback = edit_callback
            self.add_item(edit_button)

            idpw_button = discord.ui.Button(
                label="ID/PW",
                style=discord.ButtonStyle.secondary,
                disabled=self.selected_id is None,
                row=2,
            )

            async def idpw_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                scrim = (
                    repository.get(self.selected_id)
                    if self.selected_id is not None
                    else None
                )
                if scrim is None or scrim.guild_id != self.guild_id:
                    self.selected_id = None
                    self.rebuild()
                    await interaction.response.edit_message(
                        content="That scrim no longer exists.\n\n" + self.content(),
                        view=self,
                    )
                    return
                idpw_view = IdPwConfigView(
                    self, self.owner_id, self.guild_id, scrim
                )
                await interaction.response.send_message(
                    idpw_view.content(),
                    view=idpw_view,
                    ephemeral=True,
                    allowed_mentions=discord.AllowedMentions.none(),
                )

            idpw_button.callback = idpw_callback
            self.add_item(idpw_button)

            custom_emojis_button = discord.ui.Button(
                label="Custom Emojis",
                emoji="🎨",
                style=discord.ButtonStyle.secondary,
                disabled=self.selected_id is None,
                row=3,
            )

            async def custom_emojis_callback(
                interaction: discord.Interaction,
            ) -> None:
                if not await self.interaction_check(interaction):
                    return
                scrim = (
                    repository.get(self.selected_id)
                    if self.selected_id is not None
                    else None
                )
                if scrim is None or scrim.guild_id != self.guild_id:
                    self.selected_id = None
                    self.rebuild()
                    await interaction.response.edit_message(
                        content="Select a scrim first.\n\n" + self.content(),
                        view=self,
                    )
                    return
                await interaction.response.edit_message(
                    content=custom_emoji_content(scrim),
                    view=CustomEmojiMenuView(
                        self, self.owner_id, self.guild_id, scrim.id
                    ),
                )

            custom_emojis_button.callback = custom_emojis_callback
            self.add_item(custom_emojis_button)

        async def refresh_message(self) -> bool:
            try:
                self.rebuild()
            except SlotStorageError:
                logger.exception("Could not reload scrims for the setup panel")
                return False
            if self.message is None:
                return False
            try:
                await self.message.edit(content=self.content(), view=self)
                return True
            except discord.HTTPException:
                logger.exception("Could not refresh setup panel")
                return False

    def custom_emoji_content(scrim) -> str:
        return (
            f"**Custom legend emojis — {_safe_name(scrim.name)}**\n"
            f"Available: {scrim.emoji_available}\n"
            f"Reserved: {scrim.emoji_reserved}\n"
            f"Pending: {scrim.emoji_pending}\n"
            f"Confirmed: {scrim.emoji_confirmed}\n\n"
            "Choose a status to edit."
        )

    class CustomEmojiMenuView(BoundView):
        def __init__(
            self,
            panel: SetupPanel,
            owner_id: int,
            guild_id: int,
            scrim_id: str,
        ):
            super().__init__(owner_id, guild_id, timeout=600)
            self.panel = panel
            self.scrim_id = scrim_id

            async def edit_emoji(
                interaction: discord.Interaction, field_name: str
            ) -> None:
                if not await self.interaction_check(interaction):
                    return
                scrim = repository.get(self.scrim_id)
                if scrim is None or scrim.guild_id != self.guild_id:
                    await _send_error(
                        interaction,
                        ValueError("The selected scrim no longer exists."),
                    )
                    return
                await interaction.response.send_message(
                    "Please mention me and send the new emoji "
                    "(e.g., `@ARC_Bot <:my_emoji:123>`). "
                    "To cancel, type `@ARC_Bot cancel`.",
                    ephemeral=True,
                )

                def check(message: discord.Message) -> bool:
                    bot_user = bot.user
                    return bool(
                        message.author.id == interaction.user.id
                        and message.channel.id == interaction.channel_id
                        and bot_user is not None
                        and bot_user.mentioned_in(message)
                    )

                try:
                    message = await bot.wait_for(
                        'message', check=check, timeout=60.0
                    )
                except asyncio.TimeoutError:
                    result = "Emoji edit timed out."
                    message = None
                else:
                    if "cancel" in message.content.casefold():
                        result = "Emoji edit cancelled."
                    else:
                        emoji = extract_raw_emoji(message.content)
                        if emoji is None:
                            result = (
                                "No custom or Unicode emoji was found. "
                                "The emoji was not changed."
                            )
                        else:
                            try:
                                updated_scrim = repository.save_scrim_emoji(
                                    self.scrim_id, self.guild_id, field_name, emoji
                                )
                            except (SlotStorageError, ValueError):
                                logger.exception("Could not save custom legend emoji")
                                result = "The emoji could not be saved."
                            else:
                                if updated_scrim.public_message_id is not None:
                                    try:
                                        await publish_scrim(updated_scrim)
                                    except Exception:
                                        logger.exception(
                                            "Could not refresh the scrim board after "
                                            "updating its legend emoji"
                                        )
                                result = None

                try:
                    await interaction.delete_original_response()
                except discord.HTTPException:
                    logger.exception("Could not delete the emoji edit prompt")
                if message is not None:
                    try:
                        await message.delete()
                    except (
                        discord.NotFound,
                        discord.Forbidden,
                        discord.HTTPException,
                    ):
                        pass
                if result:
                    try:
                        await interaction.followup.send(result, ephemeral=True)
                    except discord.HTTPException:
                        logger.exception("Could not report emoji edit result")
                scrim = repository.get(self.scrim_id)
                if scrim is not None and interaction.message is not None:
                    try:
                        await interaction.message.edit(
                            content=custom_emoji_content(scrim),
                            view=CustomEmojiMenuView(
                                self.panel,
                                self.owner_id,
                                self.guild_id,
                                self.scrim_id,
                            ),
                        )
                    except discord.HTTPException:
                        logger.exception("Could not refresh custom emoji menu")

            buttons = (
                ("Edit Available", "emoji_available"),
                ("Edit Reserved", "emoji_reserved"),
                ("Edit Pending", "emoji_pending"),
                ("Edit Confirmed", "emoji_confirmed"),
            )
            for label, field_name in buttons:
                button = discord.ui.Button(
                    label=label,
                    style=discord.ButtonStyle.secondary,
                    row=0,
                )
                button.callback = lambda interaction, field_name=field_name: (
                    edit_emoji(interaction, field_name)
                )
                self.add_item(button)

            reset = discord.ui.Button(
                label="Reset to Defaults",
                emoji="🔄",
                style=discord.ButtonStyle.danger,
                row=1,
            )

            async def reset_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                scrim = repository.get(self.scrim_id)
                if scrim is None or scrim.guild_id != self.guild_id:
                    await _send_error(
                        interaction,
                        ValueError("The selected scrim no longer exists."),
                    )
                    return
                try:
                    scrim = repository.reset_scrim_emojis(
                        self.scrim_id, self.guild_id
                    )
                except (SlotStorageError, ValueError):
                    logger.exception("Could not reset custom legend emojis")
                    await _send_error(
                        interaction,
                        ValueError("The emojis could not be reset."),
                    )
                    return
                await interaction.response.edit_message(
                    content=custom_emoji_content(scrim),
                    view=CustomEmojiMenuView(
                        self.panel,
                        self.owner_id,
                        self.guild_id,
                        self.scrim_id,
                    ),
                )
                try:
                    confirmation = await interaction.followup.send(
                        "✅ Emojis have been reset to default.",
                        ephemeral=True,
                        wait=True,
                    )
                    if confirmation is not None:
                        await confirmation.delete(delay=5)
                except (
                    discord.NotFound,
                    discord.Forbidden,
                    discord.HTTPException,
                ):
                    logger.exception("Could not report emoji reset")

            reset.callback = reset_callback
            self.add_item(reset)

            back = discord.ui.Button(
                label="Back to Main Menu",
                style=discord.ButtonStyle.primary,
                row=2,
            )

            async def back_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                self.panel.rebuild()
                await interaction.response.edit_message(
                    content=self.panel.content(),
                    view=self.panel,
                )

            back.callback = back_callback
            self.add_item(back)

    class IdPwPasswordModal(discord.ui.Modal, title="Set match password"):
        password = discord.ui.TextInput(
            label="Fixed match password",
            placeholder="Enter the password used for the match lobby",
            min_length=1,
            max_length=100,
            required=True,
        )

        def __init__(self, config_view) -> None:
            super().__init__()
            self.config_view = config_view

        async def on_submit(self, interaction: discord.Interaction) -> None:
            if not await self.config_view.interaction_check(interaction):
                return
            password = str(self.password.value).strip()
            if not password:
                await interaction.response.send_message(
                    "The match password cannot be empty.", ephemeral=True
                )
                return
            try:
                repository.save_idpw_config(
                    self.config_view.scrim.id,
                    target_channel_id=self.config_view.channel_id,
                    fixed_password=password,
                    timezone_name=self.config_view.timezone_name,
                )
            except (SlotStorageError, ValueError):
                logger.exception("Could not save ID/password configuration")
                await interaction.response.send_message(
                    "The ID/password configuration could not be saved. "
                    "Nothing was changed.",
                    ephemeral=True,
                )
                return
            self.config_view.stop()
            await self.config_view.panel.refresh_message()
            await interaction.response.send_message(
                "ID/password alerts are configured. Use `!idpw <Lobby ID> <Minutes>` "
                "when you want to publish match access.",
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )

    class IdPwConfigView(BoundView):
        def __init__(
            self, panel: SetupPanel, owner_id: int, guild_id: int, scrim: Any
        ) -> None:
            super().__init__(owner_id, guild_id, timeout=600)
            self.panel = panel
            self.scrim = scrim
            current = repository.get_idpw_config(scrim.id)
            self.channel_id = current.target_channel_id if current else None
            self.timezone_name = (
                current.timezone_name if current else DEFAULT_IDPW_TIMEZONE
            )

            channel_picker = discord.ui.ChannelSelect(
                placeholder="Select the target text channel",
                channel_types=[discord.ChannelType.text],
                min_values=1,
                max_values=1,
                row=0,
            )

            async def channel_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                channel = interaction.guild.get_channel(channel_picker.values[0].id)
                if not isinstance(channel, discord.TextChannel):
                    await interaction.response.send_message(
                        "Select an existing text channel in this server.",
                        ephemeral=True,
                    )
                    return
                self.channel_id = channel.id
                save_button.disabled = False
                await interaction.response.edit_message(
                    content=self.content(), view=self
                )

            channel_picker.callback = channel_callback
            self.add_item(channel_picker)

            timezone_picker = discord.ui.Select(
                placeholder="Select the timezone for match times",
                options=[
                    discord.SelectOption(
                        label=label,
                        value=value,
                        default=value == self.timezone_name,
                    )
                    for value, label in IDPW_TIMEZONE_CHOICES
                ],
                min_values=1,
                max_values=1,
                row=1,
            )

            async def timezone_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                self.timezone_name = timezone_picker.values[0]
                await interaction.response.edit_message(
                    content=self.content(), view=self
                )

            timezone_picker.callback = timezone_callback
            self.add_item(timezone_picker)

            save_button = discord.ui.Button(
                label="Set password",
                style=discord.ButtonStyle.success,
                disabled=self.channel_id is None,
                row=2,
            )

            async def save_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                if self.channel_id is None:
                    await interaction.response.send_message(
                        "Select a target channel first.",
                        ephemeral=True,
                    )
                    return
                await interaction.response.send_modal(IdPwPasswordModal(self))

            save_button.callback = save_callback
            self.add_item(save_button)

            cancel_button = discord.ui.Button(
                label="Cancel", style=discord.ButtonStyle.secondary, row=2
            )

            async def cancel_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                self.stop()
                await interaction.response.edit_message(
                    content="ID/password setup cancelled.", view=None
                )

            cancel_button.callback = cancel_callback
            self.add_item(cancel_button)

        def content(self) -> str:
            channel = f"<#{self.channel_id}>" if self.channel_id else "not selected"
            return (
                f"**ID/PW — {_safe_name(self.scrim.name)}**\n"
                f"Pending Captain Role: "
                f"{f'<@&{self.scrim.pending_role_id}>' if self.scrim.pending_role_id else 'not configured'}\n"
                f"Confirmed Captain Role: "
                f"{f'<@&{self.scrim.confirmed_role_id}>' if self.scrim.confirmed_role_id else 'not configured'}\n"
                f"Target channel: {channel}\n"
                f"Timezone: `{self.timezone_name}`\n"
                "Select the target channel and timezone, then choose **Set password**. "
                "The password is never displayed in the panel."
            )

    class ManagerRoleView(BoundView):
        def __init__(
            self,
            panel: SetupPanel,
            owner_id: int,
            guild_id: int,
            name: str,
            slot_start: int = DEFAULT_SLOT_START,
            slot_end: int = DEFAULT_SLOT_END,
        ):
            super().__init__(owner_id, guild_id)
            self.panel = panel
            self.name = name
            self.slot_start = slot_start
            self.slot_end = slot_end
            picker = discord.ui.RoleSelect(
                placeholder="Select the Pending Captain Role",
                min_values=1,
                max_values=1,
            )

            async def picker_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                role = picker.values[0]
                if role.is_default() or role.managed:
                    await interaction.response.send_message(
                        "Select a regular server role, not @everyone or a managed role.",
                        ephemeral=True,
                    )
                    return
                config = repository.get_server_config(self.guild_id)
                if (
                    config is not None
                    and config.staff_role_id is not None
                    and role.id == config.staff_role_id
                ):
                    await interaction.response.send_message(
                        "The Pending Captain Role must differ from the server administration role configured with `!set`.",
                        ephemeral=True,
                    )
                    return
                await interaction.response.edit_message(
                    content=(
                        f"Pending Captain Role selected: {role.mention}\n"
                        "Now select the Confirmed Captain Role."
                    ),
                    view=ConfirmedRoleView(
                        self.panel,
                        self.owner_id,
                        self.guild_id,
                        self.name,
                        role.id,
                        self.slot_start,
                        self.slot_end,
                    ),
                )

            picker.callback = picker_callback
            self.add_item(picker)

    class ConfirmedRoleView(BoundView):
        def __init__(
            self,
            panel: SetupPanel,
            owner_id: int,
            guild_id: int,
            name: str,
            pending_role_id: int,
            slot_start: int = DEFAULT_SLOT_START,
            slot_end: int = DEFAULT_SLOT_END,
        ):
            super().__init__(owner_id, guild_id)
            self.panel = panel
            self.name = name
            self.pending_role_id = pending_role_id
            self.slot_start = slot_start
            self.slot_end = slot_end
            picker = discord.ui.RoleSelect(
                placeholder="Select the Confirmed Captain Role",
                min_values=1,
                max_values=1,
            )

            async def picker_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                role = picker.values[0]
                config = repository.get_server_config(self.guild_id)
                if (
                    role.is_default()
                    or role.managed
                    or (
                        config is not None
                        and config.staff_role_id is not None
                        and role.id == config.staff_role_id
                    )
                    or role.id == self.pending_role_id
                ):
                    await interaction.response.send_message(
                        "Select a regular role different from the Staff and Pending Captain roles.",
                        ephemeral=True,
                    )
                    return
                await interaction.response.edit_message(
                    content=(
                        f"Confirmed Captain Role selected: {role.mention}\n"
                        "Now select the public text channel for slots."
                    ),
                    view=PublicChannelView(
                        self.panel,
                        self.owner_id,
                        self.guild_id,
                        self.name,
                        self.pending_role_id,
                        role.id,
                        self.slot_start,
                        self.slot_end,
                    ),
                )

            picker.callback = picker_callback
            self.add_item(picker)

    class PublicChannelView(BoundView):
        def __init__(
            self,
            panel: SetupPanel,
            owner_id: int,
            guild_id: int,
            name: str,
            pending_role_id: int | None = None,
            confirmed_role_id: int | None = None,
            slot_start: int = DEFAULT_SLOT_START,
            slot_end: int = DEFAULT_SLOT_END,
        ):
            super().__init__(owner_id, guild_id)
            self.panel = panel
            self.name = name
            self.pending_role_id = pending_role_id
            self.confirmed_role_id = confirmed_role_id
            self.slot_start = slot_start
            self.slot_end = slot_end
            picker = discord.ui.ChannelSelect(
                placeholder="Select the public text channel",
                channel_types=[discord.ChannelType.text],
                min_values=1,
                max_values=1,
            )

            async def picker_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                channel = picker.values[0]
                resolved = interaction.guild.get_channel(channel.id)
                if not isinstance(resolved, discord.TextChannel):
                    await interaction.response.send_message(
                        "Select an existing text channel in this server.",
                        ephemeral=True,
                    )
                    return
                await interaction.response.edit_message(
                    content=(
                        f"Public channel selected: {resolved.mention}\n"
                        "Now select a distinct staff text channel."
                    ),
                    view=StaffChannelView(
                        self.panel,
                        self.owner_id,
                        self.guild_id,
                        self.name,
                        resolved.id,
                        self.pending_role_id,
                        self.confirmed_role_id,
                        self.slot_start,
                        self.slot_end,
                    ),
                )

            picker.callback = picker_callback
            self.add_item(picker)

    class StaffChannelView(BoundView):
        def __init__(
            self,
            panel: SetupPanel,
            owner_id: int,
            guild_id: int,
            name: str,
            public_channel_id: int,
            pending_role_id: int | None = None,
            confirmed_role_id: int | None = None,
            slot_start: int = DEFAULT_SLOT_START,
            slot_end: int = DEFAULT_SLOT_END,
        ):
            super().__init__(owner_id, guild_id)
            self.panel = panel
            self.name = name
            self.public_channel_id = public_channel_id
            self.pending_role_id = pending_role_id
            self.confirmed_role_id = confirmed_role_id
            self.slot_start = slot_start
            self.slot_end = slot_end
            picker = discord.ui.ChannelSelect(
                placeholder="Select the staff text channel",
                channel_types=[discord.ChannelType.text],
                min_values=1,
                max_values=1,
            )

            async def picker_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                guild = interaction.guild
                selected = picker.values[0]
                public_channel = guild.get_channel(self.public_channel_id)
                staff_channel = guild.get_channel(selected.id)
                if not isinstance(public_channel, discord.TextChannel):
                    await interaction.response.edit_message(
                        content=(
                            "The selected public channel no longer exists. "
                            "Start again with **Add scrim**."
                        ),
                        view=None,
                    )
                    return
                if not isinstance(staff_channel, discord.TextChannel):
                    await interaction.response.send_message(
                        "Select an existing text channel in this server.",
                        ephemeral=True,
                    )
                    return
                if staff_channel.id == public_channel.id:
                    await interaction.response.send_message(
                        "The public and staff channels must be different.",
                        ephemeral=True,
                    )
                    return
                permission_error = _channel_permissions_error(
                    guild, public_channel, staff_channel
                )
                if permission_error:
                    await interaction.response.send_message(
                        permission_error, ephemeral=True
                    )
                    return

                await interaction.response.edit_message(
                    content=(
                        f"Public channel selected: {public_channel.mention}\n"
                        f"Staff channel selected: {staff_channel.mention}\n"
                        "Now select the logs channel."
                    ),
                    view=LogsChannelView(
                        self.panel,
                        self.owner_id,
                        self.guild_id,
                        self.name,
                        self.pending_role_id,
                        self.confirmed_role_id,
                        public_channel.id,
                        staff_channel.id,
                        self.slot_start,
                        self.slot_end,
                    ),
                )

            picker.callback = picker_callback
            self.add_item(picker)

    class LogsChannelView(BoundView):
        def __init__(
            self,
            panel: SetupPanel,
            owner_id: int,
            guild_id: int,
            name: str,
            pending_role_id: int,
            confirmed_role_id: int,
            public_channel_id: int,
            staff_channel_id: int,
            slot_start: int = DEFAULT_SLOT_START,
            slot_end: int = DEFAULT_SLOT_END,
        ):
            super().__init__(owner_id, guild_id)
            self.panel = panel
            self.name = name
            self.pending_role_id = pending_role_id
            self.confirmed_role_id = confirmed_role_id
            self.public_channel_id = public_channel_id
            self.staff_channel_id = staff_channel_id
            self.slot_start = slot_start
            self.slot_end = slot_end
            picker = discord.ui.ChannelSelect(
                placeholder="Select the logs text channel",
                channel_types=[discord.ChannelType.text],
                min_values=1,
                max_values=1,
            )

            async def picker_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                guild = interaction.guild
                logs_channel = guild.get_channel(picker.values[0].id)
                public_channel = guild.get_channel(self.public_channel_id)
                staff_channel = guild.get_channel(self.staff_channel_id)
                if not all(
                    isinstance(channel, discord.TextChannel)
                    for channel in (public_channel, staff_channel, logs_channel)
                ):
                    await interaction.response.send_message(
                        "Select existing text channels in this server.", ephemeral=True
                    )
                    return
                if len(
                    {public_channel.id, staff_channel.id, logs_channel.id}
                ) != 3:
                    await interaction.response.send_message(
                        "Public, staff, and logs channels must be different.",
                        ephemeral=True,
                    )
                    return
                permission_error = _channel_permissions_error(
                    guild,
                    public_channel,
                    staff_channel,
                    (logs_channel, "logs"),
                )
                if permission_error:
                    await interaction.response.send_message(
                        permission_error, ephemeral=True
                    )
                    return
                await interaction.response.edit_message(
                    content=(
                        f"Logs channel selected: {logs_channel.mention}\n"
                        "Now select the Scrims History archive channel and the "
                        "designated !cap channel."
                    ),
                    view=HistoryChannelView(
                        self.panel,
                        self.owner_id,
                        self.guild_id,
                        self.name,
                        self.pending_role_id,
                        self.confirmed_role_id,
                        self.public_channel_id,
                        self.staff_channel_id,
                        logs_channel.id,
                        self.slot_start,
                        self.slot_end,
                    ),
                )

            picker.callback = picker_callback
            self.add_item(picker)

    class HistoryChannelView(BoundView):
        def __init__(
            self,
            panel: SetupPanel,
            owner_id: int,
            guild_id: int,
            name: str,
            pending_role_id: int,
            confirmed_role_id: int,
            public_channel_id: int,
            staff_channel_id: int,
            logs_channel_id: int,
            slot_start: int = DEFAULT_SLOT_START,
            slot_end: int = DEFAULT_SLOT_END,
        ):
            super().__init__(owner_id, guild_id)
            self.panel = panel
            self.name = name
            self.pending_role_id = pending_role_id
            self.confirmed_role_id = confirmed_role_id
            self.public_channel_id = public_channel_id
            self.staff_channel_id = staff_channel_id
            self.logs_channel_id = logs_channel_id
            self.slot_start = slot_start
            self.slot_end = slot_end
            self.cap_channel_id: int | None = None
            picker = discord.ui.ChannelSelect(
                placeholder="Select the Scrims History text channel",
                channel_types=[discord.ChannelType.text],
                min_values=1,
                max_values=1,
            )
            cap_picker = discord.ui.ChannelSelect(
                placeholder="Select the designated !cap text channel",
                channel_types=[discord.ChannelType.text],
                min_values=1,
                max_values=1,
                row=1,
            )

            async def cap_picker_callback(
                interaction: discord.Interaction,
            ) -> None:
                if not await self.interaction_check(interaction):
                    return
                guild = interaction.guild
                cap_channel = guild.get_channel(cap_picker.values[0].id)
                if not isinstance(cap_channel, discord.TextChannel):
                    await interaction.response.send_message(
                        "Select an existing text channel in this server.",
                        ephemeral=True,
                    )
                    return
                if cap_channel.id in {
                    self.public_channel_id,
                    self.staff_channel_id,
                    self.logs_channel_id,
                }:
                    await interaction.response.send_message(
                        "The !cap channel must be different from the public, staff, and logs channels.",
                        ephemeral=True,
                    )
                    return
                member = guild.me
                permissions = cap_channel.permissions_for(member) if member else None
                required = (
                    "view_channel",
                    "send_messages",
                    "read_message_history",
                    "manage_messages",
                )
                missing = [
                    permission.replace("_", " ").title()
                    for permission in required
                    if permissions is None
                    or not getattr(permissions, permission, False)
                ]
                if missing:
                    await interaction.response.send_message(
                        f"I am missing {', '.join(missing)} in {cap_channel.mention}.",
                        ephemeral=True,
                    )
                    return
                self.cap_channel_id = cap_channel.id
                await interaction.response.edit_message(
                    content=(
                        "Select the Scrims History channel and the designated "
                        f"!cap channel. Current !cap channel: {cap_channel.mention}"
                    ),
                    view=self,
                )

            async def picker_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                if self.cap_channel_id is None:
                    await interaction.response.send_message(
                        "Select the designated !cap channel before completing scrim setup.",
                        ephemeral=True,
                    )
                    return
                guild = interaction.guild
                history_channel = guild.get_channel(picker.values[0].id)
                cap_channel = guild.get_channel(self.cap_channel_id)
                channels = [
                    guild.get_channel(channel_id)
                    for channel_id in (
                        self.public_channel_id,
                        self.staff_channel_id,
                        self.logs_channel_id,
                    )
                ]
                if (
                    not isinstance(history_channel, discord.TextChannel)
                    or not isinstance(cap_channel, discord.TextChannel)
                    or not all(
                        isinstance(channel, discord.TextChannel)
                        for channel in channels
                    )
                ):
                    await interaction.response.send_message(
                        "Select existing text channels in this server.", ephemeral=True
                    )
                    return
                all_channels = [*channels, history_channel, cap_channel]
                if len({channel.id for channel in all_channels}) != 5:
                    await interaction.response.send_message(
                        "Public, staff, logs, history, and !cap channels must be different.",
                        ephemeral=True,
                    )
                    return
                permission_error = _channel_permissions_error(
                    guild,
                    channels[0],
                    channels[1],
                    (channels[2], "logs"),
                    (history_channel, "history"),
                    (cap_channel, "!cap"),
                )
                if permission_error:
                    await interaction.response.send_message(
                        permission_error, ephemeral=True
                    )
                    return

                legacy = getattr(repository, "legacy", None)
                legacy_board = (
                    legacy.get("public_board") if isinstance(legacy, dict) else None
                )
                adopted_legacy = (
                    isinstance(legacy_board, dict)
                    and legacy_board.get("channel_id") == self.public_channel_id
                )
                config = repository.get_server_config(self.guild_id)
                if config is None or config.staff_role_id is None:
                    await interaction.response.send_message(
                        "The global Staff role is unavailable. Run `!set <@Role>` first.",
                        ephemeral=True,
                    )
                    return
                await interaction.response.defer()
                try:
                    scrim = repository.create(
                        self.guild_id,
                        self.name,
                        self.public_channel_id,
                        self.staff_channel_id,
                        staff_role_id=config.staff_role_id,
                        pending_role_id=self.pending_role_id,
                        confirmed_role_id=self.confirmed_role_id,
                        cap_channel_id=self.cap_channel_id,
                        logs_channel_id=self.logs_channel_id,
                        history_channel_id=history_channel.id,
                        is_open=False,
                        slot_start=self.slot_start,
                        slot_end=self.slot_end,
                    )
                except ValueError:
                    await interaction.edit_original_response(
                        content=(
                            "The scrim was not created. Its name or channels conflict "
                            "with another scrim, or this server has reached its limit."
                        ),
                        view=None,
                    )
                    return
                except SlotStorageError:
                    await interaction.edit_original_response(
                        content=(
                            "The scrim could not be saved. Nothing was created. "
                            "Please try again."
                        ),
                        view=None,
                    )
                    return

                try:
                    published = await publish_scrim(scrim)
                except Exception as error:
                    logger.exception(
                        "Scrim saved but initial board publish failed", exc_info=error
                    )
                    published = False
                panel_refreshed = await self.panel.refresh_message()
                result = (
                    f"Scrim **{_safe_name(scrim.name)}** was saved in a closed state "
                    f"with its slot board in <#{scrim.public_channel_id}>."
                    if published
                    else (
                        f"Scrim **{_safe_name(scrim.name)}** was saved, but its slot "
                        "board could not be published. Check my permissions and use "
                        "the setup panel again."
                    )
                )
                if adopted_legacy:
                    result += " Existing legacy slots were preserved."
                if not panel_refreshed:
                    result += " Reopen `!setup` to refresh the panel."
                if log_action is not None:
                    try:
                        await log_action(
                            scrim,
                            "SCRIM CREATED",
                            _scrim_configuration_details(scrim),
                        )
                    except Exception:
                        logger.exception("Could not write scrim creation log")
                await interaction.edit_original_response(content=result, view=None)

            picker.callback = picker_callback
            cap_picker.callback = cap_picker_callback
            self.add_item(picker)
            self.add_item(cap_picker)

    class ScrimEditView(BoundView):
        def __init__(
            self,
            panel: "SetupPanel",
            owner_id: int,
            guild_id: int,
            scrim_id: str,
        ):
            super().__init__(owner_id, guild_id, timeout=600)
            self.panel = panel
            self.scrim_id = scrim_id

            async def edit_name(interaction: discord.Interaction) -> None:
                if await self.interaction_check(interaction):
                    scrim = repository.get(self.scrim_id)
                    if scrim is None:
                        await interaction.response.send_message(
                            "That scrim no longer exists.", ephemeral=True
                        )
                    else:
                        await interaction.response.send_modal(
                            ScrimNameEditModal(self)
                        )

            async def edit_captain_role(
                interaction: discord.Interaction, field: str, label: str
            ) -> None:
                if await self.interaction_check(interaction):
                    await interaction.response.send_message(
                        f"Select the {label} for this scrim.",
                        view=ScrimRolePicker(self, field, label),
                        ephemeral=True,
                    )

            async def edit_range(interaction: discord.Interaction) -> None:
                if await self.interaction_check(interaction):
                    scrim = repository.get(self.scrim_id)
                    if scrim is None:
                        await interaction.response.send_message(
                            "That scrim no longer exists.", ephemeral=True
                        )
                    else:
                        await interaction.response.send_modal(
                            SlotRangeModal(self)
                        )

            async def edit_channel(
                interaction: discord.Interaction, field: str, label: str
            ) -> None:
                if await self.interaction_check(interaction):
                    await interaction.response.send_message(
                        f"Select the {label} channel.",
                        view=ScrimChannelPicker(self, field),
                        ephemeral=True,
                    )

            name_button = discord.ui.Button(
                label="Scrim name", emoji="✏️", style=discord.ButtonStyle.primary, row=0
            )
            pending_role_button = discord.ui.Button(
                label="Pending Captain Role", emoji="🎭",
                style=discord.ButtonStyle.secondary, row=0
            )
            confirmed_role_button = discord.ui.Button(
                label="Confirmed Captain Role", emoji="🎭",
                style=discord.ButtonStyle.secondary, row=0
            )
            cap_channel_button = discord.ui.Button(
                label="Set !cap Channel",
                emoji="⚙️",
                style=discord.ButtonStyle.secondary,
                row=0,
            )
            public_button = discord.ui.Button(
                label="Public channel", emoji="📣",
                style=discord.ButtonStyle.secondary, row=1
            )
            staff_button = discord.ui.Button(
                label="Staff channel", emoji="🔒",
                style=discord.ButtonStyle.secondary, row=1
            )
            logs_button = discord.ui.Button(
                label="Logs channel", emoji="📝",
                style=discord.ButtonStyle.secondary, row=2
            )
            history_button = discord.ui.Button(
                label="History channel", emoji="🗄️",
                style=discord.ButtonStyle.secondary, row=2
            )
            range_button = discord.ui.Button(
                label="Slot range", emoji="🔢",
                style=discord.ButtonStyle.secondary, row=3
            )
            close_button = discord.ui.Button(
                label="Close", style=discord.ButtonStyle.danger, row=4
            )

            name_button.callback = edit_name
            pending_role_button.callback = lambda interaction: edit_captain_role(
                interaction, "pending_role_id", "Pending Captain Role"
            )
            confirmed_role_button.callback = lambda interaction: edit_captain_role(
                interaction, "confirmed_role_id", "Confirmed Captain Role"
            )
            public_button.callback = lambda interaction: edit_channel(
                interaction, "public_channel_id", "public"
            )
            staff_button.callback = lambda interaction: edit_channel(
                interaction, "staff_channel_id", "staff"
            )
            logs_button.callback = lambda interaction: edit_channel(
                interaction, "logs_channel_id", "logs"
            )
            history_button.callback = lambda interaction: edit_channel(
                interaction, "history_channel_id", "history"
            )
            cap_channel_button.callback = lambda interaction: edit_channel(
                interaction, "cap_channel_id", "!cap"
            )
            range_button.callback = edit_range

            async def close_callback(interaction: discord.Interaction) -> None:
                if await self.interaction_check(interaction):
                    await interaction.response.edit_message(
                        content="Scrim editing closed.", view=None
                    )

            close_button.callback = close_callback
            for item in (
                name_button,
                pending_role_button,
                confirmed_role_button,
                cap_channel_button,
                public_button,
                staff_button,
                logs_button,
                history_button,
                range_button,
                close_button,
            ):
                self.add_item(item)

        @staticmethod
        def content(scrim: Any) -> str:
            return (
                f"**Edit scrim — {_safe_name(scrim.name)}**\n"
                f"**Pending Captain Role:** "
                f"{f'<@&{scrim.pending_role_id}>' if scrim.pending_role_id else 'not configured'}\n"
                f"**Confirmed Captain Role:** "
                f"{f'<@&{scrim.confirmed_role_id}>' if scrim.confirmed_role_id else 'not configured'}\n"
                f"!cap channel: {_channel_ref(scrim.cap_channel_id)}\n"
                f"Public channel: {_channel_ref(scrim.public_channel_id)}\n"
                f"Staff channel: {_channel_ref(scrim.staff_channel_id)}\n"
                f"Logs channel: {_channel_ref(scrim.logs_channel_id)}\n"
                f"History channel: {_channel_ref(scrim.history_channel_id)}\n\n"
                f"Slots: {scrim.slot_start:02d}–{scrim.slot_end:02d} "
                f"({len(scrim.slots)} total)\n\n"
                "Choose one setting to change. Each change is saved immediately."
            )

    class ScrimRolePicker(BoundView):
        def __init__(self, edit_view: ScrimEditView, field: str, label: str):
            super().__init__(
                edit_view.owner_id, edit_view.guild_id, timeout=300
            )
            self.edit_view = edit_view
            self.field = field
            picker = discord.ui.RoleSelect(
                placeholder=f"Select the {label}",
                min_values=1,
                max_values=1,
            )

            async def callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                role = picker.values[0]
                if role.is_default() or role.managed:
                    await _send_error(
                        interaction,
                        ValueError(
                            "Select a regular server role, not @everyone or a managed role."
                        ),
                    )
                    return
                scrim = repository.get(self.edit_view.scrim_id)
                config = repository.get_server_config(self.edit_view.guild_id)
                if (
                    scrim is not None
                    and config is not None
                    and config.staff_role_id is not None
                    and role.id == config.staff_role_id
                ):
                    await _send_error(
                        interaction,
                        ValueError(
                            "The Captain roles must differ from the server administration role configured with `!set`."
                        ),
                    )
                    return
                if (
                    scrim is not None
                    and self.field == "pending_role_id"
                    and scrim.confirmed_role_id == role.id
                ) or (
                    scrim is not None
                    and self.field == "confirmed_role_id"
                    and scrim.pending_role_id == role.id
                ):
                    await _send_error(
                        interaction,
                        ValueError("Pending and Confirmed Captain roles must be different."),
                    )
                    return
                await interaction.response.defer()
                await apply_scrim_change(
                    interaction,
                    self.edit_view.panel,
                    self.edit_view.scrim_id,
                    changes={self.field: role.id},
                )

            picker.callback = callback
            self.add_item(picker)

    class ScrimChannelPicker(BoundView):
        def __init__(self, edit_view: ScrimEditView, field: str):
            super().__init__(
                edit_view.owner_id, edit_view.guild_id, timeout=300
            )
            self.edit_view = edit_view
            self.field = field
            picker = discord.ui.ChannelSelect(
                placeholder=f"Select the {field.replace('_channel_id', '')} channel",
                channel_types=[discord.ChannelType.text],
                min_values=1,
                max_values=1,
            )

            async def callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                channel = interaction.guild.get_channel(picker.values[0].id)
                if not isinstance(channel, discord.TextChannel):
                    await interaction.response.send_message(
                        "Select an existing text channel in this server.",
                        ephemeral=True,
                    )
                    return
                member = interaction.guild.me
                permissions = channel.permissions_for(member) if member else None
                required = ("view_channel", "send_messages", "read_message_history")
                missing = [
                    permission.replace("_", " ").title()
                    for permission in required
                    if permissions is None or not getattr(permissions, permission, False)
                ]
                if self.field in {"public_channel_id", "cap_channel_id"} and (
                    permissions is None or not permissions.manage_messages
                ):
                    missing.append("Manage Messages")
                if missing:
                    await interaction.response.send_message(
                        f"I am missing {', '.join(missing)} in {channel.mention}.",
                        ephemeral=True,
                    )
                    return
                await interaction.response.defer()
                await apply_scrim_change(
                    interaction,
                    self.edit_view.panel,
                    self.edit_view.scrim_id,
                    changes={self.field: channel.id},
                )

            picker.callback = callback
            self.add_item(picker)

    class ScrimNameEditModal(discord.ui.Modal, title="Edit scrim name"):
        name = discord.ui.TextInput(
            label="Scrim name",
            min_length=1,
            max_length=80,
        )

        def __init__(self, edit_view: ScrimEditView):
            super().__init__(timeout=300)
            self.edit_view = edit_view
            scrim = repository.get(edit_view.scrim_id)
            if scrim is not None:
                self.name.default = scrim.name

        async def on_submit(self, interaction: discord.Interaction) -> None:
            if not setup_authorized(
                interaction, self.edit_view.owner_id, self.edit_view.guild_id
            ):
                await _deny(interaction)
                return
            await apply_scrim_change(
                interaction,
                self.edit_view.panel,
                self.edit_view.scrim_id,
                changes={"name": str(self.name).strip()},
                response_mode="modal",
            )

        async def on_error(
            self, interaction: discord.Interaction, error: Exception
        ) -> None:
            await _send_error(interaction, error)

    class SlotRangeModal(discord.ui.Modal, title="Edit slot range"):
        slot_start = discord.ui.TextInput(
            label="First slot number",
            placeholder="Example: 01, 03, or 05",
            min_length=1,
            max_length=2,
        )
        slot_count = discord.ui.TextInput(
            label="Number of slots",
            placeholder="Example: 16, 23, or 25",
            min_length=1,
            max_length=2,
        )

        def __init__(self, edit_view: ScrimEditView):
            super().__init__(timeout=300)
            self.edit_view = edit_view
            scrim = repository.get(edit_view.scrim_id)
            if scrim is not None:
                self.slot_start.default = f"{scrim.slot_start:02d}"
                self.slot_count.default = str(scrim.slot_end - scrim.slot_start + 1)

        async def on_submit(self, interaction: discord.Interaction) -> None:
            if not setup_authorized(
                interaction, self.edit_view.owner_id, self.edit_view.guild_id
            ):
                await _deny(interaction)
                return
            try:
                start, end = _slot_range_from_count(
                    self.slot_start, self.slot_count
                )
            except (TypeError, ValueError) as error:
                await interaction.response.send_message(
                    f"Invalid slot range. {error}",
                    ephemeral=True,
                )
                return
            await apply_scrim_change(
                interaction,
                self.edit_view.panel,
                self.edit_view.scrim_id,
                changes={"slot_start": start, "slot_end": end},
                response_mode="modal",
            )

        async def on_error(
            self, interaction: discord.Interaction, error: Exception
        ) -> None:
            await _send_error(interaction, error)

    class ScrimNameModal(discord.ui.Modal, title="Add a scrim"):
        name = discord.ui.TextInput(
            label="Scrim name",
            placeholder="Example: Friday Night Scrim",
            min_length=1,
            max_length=80,
        )
        slot_start = discord.ui.TextInput(
            label="First slot number",
            placeholder="Example: 01, 03, or 05",
            default=f"{DEFAULT_SLOT_START:02d}",
            min_length=1,
            max_length=2,
        )
        slot_count = discord.ui.TextInput(
            label="Number of slots",
            placeholder="Example: 16, 23, or 25",
            default="23",
            min_length=1,
            max_length=2,
        )

        def __init__(self, panel: SetupPanel, owner_id: int, guild_id: int):
            super().__init__(timeout=300)
            self.panel = panel
            self.owner_id = owner_id
            self.guild_id = guild_id

        async def on_submit(self, interaction: discord.Interaction) -> None:
            if not setup_authorized(
                interaction, self.owner_id, self.guild_id
            ):
                await _deny(interaction)
                return
            name = str(self.name).strip()
            if not name:
                await interaction.response.send_message(
                    "The scrim name cannot be empty.", ephemeral=True
                )
                return
            try:
                slot_start, slot_end = _slot_range_from_count(
                    self.slot_start, self.slot_count
                )
            except (TypeError, ValueError) as error:
                await interaction.response.send_message(
                    f"Invalid slot range. {error}",
                    ephemeral=True,
                )
                return
            try:
                scrims = repository.list(self.guild_id)
            except SlotStorageError as error:
                await _send_error(interaction, error)
                return
            if any(scrim.name.casefold() == name.casefold() for scrim in scrims):
                await interaction.response.send_message(
                    "A scrim with that name already exists in this server.",
                    ephemeral=True,
                )
                return
            if len(scrims) >= 25:
                await interaction.response.send_message(
                    "This server already has the maximum of 25 configured scrims.",
                    ephemeral=True,
                )
                return
            await interaction.response.send_message(
                f"Creating **{_safe_name(name)}**. Select the Pending Captain Role.",
                view=ManagerRoleView(
                    self.panel,
                    self.owner_id,
                    self.guild_id,
                    name,
                    slot_start,
                    slot_end,
                ),
                ephemeral=True,
            )

        async def on_error(
            self, interaction: discord.Interaction, error: Exception
        ) -> None:
            await _send_error(interaction, error)

    class DeleteConfirmation(BoundView):
        def __init__(
            self,
            panel: SetupPanel,
            owner_id: int,
            guild_id: int,
            scrim_id: str,
        ):
            super().__init__(owner_id, guild_id, timeout=120)
            self.panel = panel
            self.scrim_id = scrim_id

            confirm = discord.ui.Button(
                label="Delete permanently", style=discord.ButtonStyle.danger
            )
            cancel = discord.ui.Button(
                label="Cancel", style=discord.ButtonStyle.secondary
            )

            async def confirm_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                selected_scrim = repository.get(self.scrim_id)
                if (
                    selected_scrim is None
                    or selected_scrim.guild_id != self.guild_id
                ):
                    await interaction.response.edit_message(
                        content="That scrim no longer exists.", view=None
                    )
                    await self.panel.refresh_message()
                    return

                await interaction.response.defer()
                deleted = None
                cleanup_error: str | None = None
                try:
                    # Match every board/state mutation's lock order. Keeping the
                    # board lock through cleanup prevents an in-flight publisher
                    # or reset from touching a replacement board on this channel.
                    async with selected_scrim.board_lock:
                        async with selected_scrim.state_lock:
                            if not setup_authorized(
                                interaction, self.owner_id, self.guild_id
                            ):
                                await _deny(interaction)
                                return
                            current = repository.get(self.scrim_id)
                            if (
                                current is not selected_scrim
                                or current.guild_id != self.guild_id
                            ):
                                raise ValueError("Scrim identity vanished.")
                            # Durable deletion precedes best-effort Discord cleanup.
                            deleted = repository.delete(
                                self.scrim_id, self.guild_id
                            )

                        old_message = getattr(deleted, "runtime_message", None)
                        try:
                            if (
                                old_message is None
                                and deleted.public_message_id is not None
                            ):
                                channel = interaction.guild.get_channel(
                                    deleted.public_channel_id
                                )
                                if not isinstance(channel, discord.TextChannel):
                                    cleanup_error = (
                                        "the old public channel is unavailable"
                                    )
                                else:
                                    old_message = await channel.fetch_message(
                                        deleted.public_message_id
                                    )
                            if old_message is not None:
                                await old_message.edit(view=None)
                        except (
                            discord.NotFound,
                            discord.Forbidden,
                            discord.HTTPException,
                        ):
                            logger.exception(
                                "Could not remove deleted scrim board controls"
                            )
                            cleanup_error = (
                                "Discord would not let me remove the old controls"
                            )
                except ValueError:
                    await interaction.edit_original_response(
                        content="That scrim no longer exists.", view=None
                    )
                    await self.panel.refresh_message()
                    return
                except SlotStorageError:
                    await interaction.edit_original_response(
                        content=(
                            "The scrim could not be deleted from storage. "
                            "Nothing was changed."
                        ),
                        view=None,
                    )
                    return

                if self.panel.selected_id == self.scrim_id:
                    self.panel.selected_id = None
                panel_refreshed = await self.panel.refresh_message()
                result = (
                    f"Scrim **{_safe_name(deleted.name)}** and its saved slot data "
                    "were deleted. Its Discord channels were not deleted."
                )
                if cleanup_error:
                    result += (
                        f" The scrim is deleted, but {cleanup_error}; any old board "
                        "controls are no longer valid."
                    )
                if not panel_refreshed:
                    result += " Reopen `!setup` to refresh the management panel."
                if log_action is not None:
                    try:
                        await log_action(
                            deleted,
                            "SCRIM DELETED",
                            "The scrim configuration and saved slot data were deleted by an administrator.",
                        )
                    except Exception:
                        logger.exception("Could not write scrim deletion log")
                await interaction.edit_original_response(content=result, view=None)

            async def cancel_callback(interaction: discord.Interaction) -> None:
                if not await self.interaction_check(interaction):
                    return
                await interaction.response.edit_message(
                    content="Deletion cancelled. Nothing was changed.", view=None
                )

            confirm.callback = confirm_callback
            cancel.callback = cancel_callback
            self.add_item(confirm)
            self.add_item(cancel)

    async def start_scrim_wizard(interaction: discord.Interaction) -> None:
        """Launch the scrim wizard from another setup flow."""
        if interaction.guild is None:
            await interaction.response.send_message(
                "This setup wizard can only be used in a server.", ephemeral=True
            )
            return
        panel = SetupPanel(interaction.user.id, interaction.guild.id)
        await interaction.response.send_modal(
            ScrimNameModal(panel, interaction.user.id, interaction.guild.id)
        )

    bot.start_scrim_wizard = start_scrim_wizard

    @bot.command(name="setup")
    @commands.guild_only()
    async def setup_command(ctx: commands.Context[commands.Bot]) -> None:
        """Open the management panel bound to the invoking staff member."""
        try:
            authorized = user_is_staff(ctx.author, ctx.guild.id)
        except SlotStorageError:
            logger.exception("Could not read scrim configuration")
            await _delete_command_message(ctx)
            await ctx.send(
                "The scrim configuration could not be read. "
                "Nothing was changed. Please try again.",
                delete_after=15,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return
        if not authorized:
            await _delete_command_message(ctx)
            await ctx.send(
                "You do not have the configured Staff role to use `!setup`.",
                delete_after=15,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return
        try:
            panel = SetupPanel(ctx.author.id, ctx.guild.id)
        except SlotStorageError:
            logger.exception("Could not read scrim configuration")
            await _delete_command_message(ctx)
            await ctx.send(
                "The scrim configuration could not be read. "
                "Nothing was changed. Please try again.",
                delete_after=15,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return
        panel.message = await ctx.send(
            panel.content(),
            view=panel,
            allowed_mentions=discord.AllowedMentions.none(),
        )