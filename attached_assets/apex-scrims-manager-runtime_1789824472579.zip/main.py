"""Gestionnaire multi-scrim de slots PUBG Mobile."""

from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path

import discord
from discord.ext import commands

from slot_storage import SlotStateStore, SlotStorageError
from scrim_state import (
    STATUS_AVAILABLE,
    STATUS_CANCELLED,
    STATUS_CONFIRMED,
    STATUS_PENDING,
    STATUS_RESERVED,
    Scrim,
    ScrimRepository,
    Slot,
    SlotSnapshot,
    timezone_for_name,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("pung-scrim-bot")

# Cancelled assignments remain visible in red until staff reuse the slot.
# Cancelled assignments are released immediately by default.  Staff still
# receives the cancellation snapshot in its notification and history log.
AUTO_RELEASE_CANCELLED = True
FIGURE_SPACE = "\u2007"

state_store = SlotStateStore(
    os.getenv("SLOTS_DB_PATH", str(Path(__file__).parent / "data" / "slots.sqlite3"))
)
repository = ScrimRepository(state_store)

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)
_setup_installed = False
_global_setup_installed = False
_loaded = False
# Each scrim owns its own live announcement and alert tasks.
active_idpw: dict[str, dict[str, object]] = {}


def is_active(scrim: Scrim) -> bool:
    return not scrim.deleted and repository.get(scrim.id) is scrim


def assignment_fingerprint(scrim: Scrim) -> str:
    generations = ",".join(
        f"{slot.number}:{slot.assignment_id}" for slot in scrim.slots.values()
    )
    return hashlib.sha256(f"{scrim.id}:{generations}".encode()).hexdigest()[:24]


def slot_status_emoji(slot: Slot | SlotSnapshot) -> str:
    return {
        STATUS_RESERVED: "🔵",
        STATUS_PENDING: "🟠",
        STATUS_CONFIRMED: "🟢",
        STATUS_CANCELLED: "⚪️" if AUTO_RELEASE_CANCELLED else "🔴",
    }.get(slot.status, "⚪️")


def slot_status_label(slot: Slot | SlotSnapshot) -> str:
    return {
        STATUS_AVAILABLE: "Available",
        STATUS_RESERVED: "Reserved",
        STATUS_PENDING: "Pending",
        STATUS_CONFIRMED: "Confirmed",
        STATUS_CANCELLED: "Cancelled",
    }.get(slot.status, "Unknown")


def slot_is_assignable(slot: Slot | SlotSnapshot) -> bool:
    return slot.status in (STATUS_AVAILABLE, STATUS_CANCELLED)


def cancel_slot(slot: Slot) -> SlotSnapshot:
    slot.status = STATUS_CANCELLED
    audit = slot.snapshot()
    if AUTO_RELEASE_CANCELLED:
        slot.clear()
    return audit


def disable_view_items(view: discord.ui.View) -> None:
    for item in view.children:
        if isinstance(item, discord.ui.DynamicItem):
            item = item.item
        if hasattr(item, "disabled"):
            item.disabled = True


def slot_display_line(slot: Slot) -> str:
    prefix = f"`{slot.number:02d}{FIGURE_SPACE}{slot_status_emoji(slot)}`"
    if slot.status == STATUS_AVAILABLE:
        return prefix
    manager = f"<@{slot.manager_id}>" if slot.manager_id else "Not specified"
    suffix = " | Cancelled" if slot.status == STATUS_CANCELLED else ""
    return f"{prefix}{FIGURE_SPACE}{slot.team_name} | {slot.tag} | {manager}{suffix}"


def build_slots_message(scrim: Scrim) -> str:
    legend = (
        "⚪️ Available · 🔵 Reserved · 🟠 Pending\n"
        "🟢 Confirmed · 🔴 Cancelled"
    )
    return (
        f"**{discord.utils.escape_markdown(scrim.name)}**\n"
        f"{legend}\n\n"
        + "\n".join(slot_display_line(slot) for slot in scrim.slots.values())
        + "\n\n_PUBG Mobile Scrim Slot Manager_"
    )


def build_staff_slots_message(scrim: Scrim) -> str:
    return (
        f"**Staff mirror — {discord.utils.escape_markdown(scrim.name)}**\n"
        f"{'OPEN' if scrim.is_open else 'CLOSED'} · updates remain in this channel\n\n"
        + "\n".join(slot_display_line(slot) for slot in scrim.slots.values())
    )


def member_is_staff(member: object, scrim: Scrim) -> bool:
    roles = {getattr(role, "id", None) for role in getattr(member, "roles", ())}
    config = repository.get_server_config(scrim.guild_id)
    return bool(config and config.staff_role_id is not None and config.staff_role_id in roles)


def member_is_admin(member: object) -> bool:
    permissions = getattr(member, "guild_permissions", None)
    return bool(
        permissions is not None and getattr(permissions, "administrator", False)
    )


def member_is_head_staff(member: object, guild_id: int) -> bool:
    if member_is_admin(member):
        return True
    config = repository.get_server_config(guild_id)
    return bool(
        config
        and config.head_staff_role_id in {
            getattr(role, "id", None) for role in getattr(member, "roles", ())
        }
    )


async def require_staff_scrim(
    ctx: commands.Context,
    *,
    public_only: bool = False,
    allow_public: bool = False,
) -> Scrim | None:
    if ctx.guild is None:
        await send_private_command_feedback(
            ctx, "This command can only be used in a Discord server.", silent=True
        )
        return None
    scrim = resolve_channel_scrim(ctx)
    allowed_channel_ids = (
        (scrim.public_channel_id, scrim.staff_channel_id)
        if scrim is not None and allow_public
        else (scrim.public_channel_id,)
        if scrim is not None and public_only
        else (scrim.staff_channel_id,)
        if scrim is not None
        else ()
    )
    if scrim is None or ctx.channel.id not in allowed_channel_ids:
        if public_only:
            message = "This command must be used in the configured public slots channel."
        elif allow_public:
            message = "This command must be used in the configured public or staff channel."
        else:
            message = "This command must be used in the configured staff channel."
        await send_private_command_feedback(
            ctx,
            message,
            silent=True,
        )
        return None
    if not member_is_staff(ctx.author, scrim):
        await send_private_command_feedback(
            ctx, "You do not have the staff role authorized for this scrim.",
            silent=True,
        )
        return None
    return scrim


async def delete_command_message(ctx: commands.Context) -> bool:
    message = getattr(ctx, "message", None)
    delete = getattr(message, "delete", None)
    if delete is None:
        return False
    try:
        await delete()
        return True
    except (discord.NotFound, discord.Forbidden, discord.HTTPException):
        return False


async def send_private_command_feedback(
    ctx: commands.Context,
    content: str,
    *,
    delete_command: bool = True,
    silent: bool = False,
    **kwargs,
):
    """Send routine prefix-command feedback in the invoking channel."""
    if silent:
        if delete_command:
            await delete_command_message(ctx)
        return None
    send_kwargs = dict(kwargs)
    send_kwargs.setdefault("delete_after", 15)
    sent = None
    try:
        sent = await ctx.send(
            content,
            allowed_mentions=discord.AllowedMentions.none(),
            **send_kwargs,
        )
    except discord.HTTPException:
        logger.exception("Could not send command feedback.")
    if delete_command:
        await delete_command_message(ctx)
    return sent


async def purge_channel_messages(channel) -> bool:
    """Clear a channel in batches, reporting failure without aborting reset."""
    purge = getattr(channel, "purge", None)
    if purge is None:
        return False
    try:
        while True:
            deleted = await purge(limit=100)
            if len(deleted) < 100:
                return True
    except discord.Forbidden:
        return False
    except discord.HTTPException:
        logger.exception("Could not clear channel %s.", getattr(channel, "id", None))
        return False


async def get_channel(channel_id: int):
    channel = bot.get_channel(channel_id)
    return channel if channel is not None else await bot.fetch_channel(channel_id)


async def configured_idpw_channel(guild: discord.Guild, channel_id: int):
    """Resolve an ID/password channel without crossing the configured guild."""
    try:
        channel = guild.get_channel(channel_id)
        if channel is None:
            channel = await bot.fetch_channel(channel_id)
    except (discord.NotFound, discord.Forbidden, discord.HTTPException):
        logger.exception(
            "Could not resolve the configured ID/password channel (%s).",
            channel_id,
        )
        return None
    channel_guild = getattr(channel, "guild", None)
    if (
        not isinstance(channel, discord.TextChannel)
        or channel_guild is None
        or channel_guild.id != guild.id
    ):
        logger.error(
            "Invalid configured ID/password channel for guild %s (channel %s).",
            guild.id,
            channel_id,
        )
        return None
    return channel


async def clear_active_idpw(scrim_id: str | None = None) -> None:
    """Cancel ID/PW alerts and remove the persisted announcement for a scrim."""
    scrim_ids = (
        [scrim_id]
        if scrim_id is not None
        else list(set(active_idpw) | set(repository.idpw_configs))
    )
    for current_id in scrim_ids:
        state = active_idpw.pop(current_id, {})
        for task in state.get("tasks", []):
            if not task.done():
                task.cancel()

        message = state.get("message")
        config = repository.get_idpw_config(current_id)
        scrim = repository.get(current_id)
        if message is None and config is not None and scrim is not None:
            try:
                channel = await configured_text_channel(
                    scrim, config.target_channel_id
                )
                fetch_message = getattr(channel, "fetch_message", None)
                if fetch_message is not None and config.announcement_message_id:
                    message = await fetch_message(config.announcement_message_id)
            except discord.NotFound:
                pass
            except (discord.Forbidden, discord.HTTPException):
                logger.exception(
                    "Could not resolve the MATCH ACCESS message for scrim %s.",
                    current_id,
                )

        if message is not None:
            try:
                await message.delete()
            except discord.NotFound:
                pass
            except (discord.Forbidden, discord.HTTPException):
                logger.exception(
                    "Could not delete the MATCH ACCESS message for scrim %s.",
                    current_id,
                )

        if config is not None and config.announcement_message_id is not None:
            try:
                repository.set_idpw_announcement(current_id, None)
            except (SlotStorageError, ValueError):
                logger.exception(
                    "Could not clear the MATCH ACCESS reference for scrim %s.",
                    current_id,
                )


async def configured_text_channel(scrim: Scrim, channel_id: int):
    """Resolve a configured text channel without crossing the scrim's guild."""
    channel = await get_channel(channel_id)
    guild = getattr(channel, "guild", None)
    if not isinstance(channel, discord.TextChannel) or guild is None or guild.id != scrim.guild_id:
        logger.error(
            "Invalid configured text channel for scrim %s (channel %s).",
            scrim.id,
            channel_id,
        )
        return None
    return channel


def resolve_named_scrim(guild_id: int, name: str) -> Scrim | None:
    folded = name.strip().casefold()
    return next((s for s in repository.list(guild_id) if s.name.casefold() == folded), None)


def resolve_channel_scrim(ctx: commands.Context, *, staff_only: bool = False) -> Scrim | None:
    if ctx.guild is None:
        return None
    matches = [
        scrim for scrim in repository.list(ctx.guild.id)
        if ctx.channel.id in (
            (scrim.staff_channel_id,) if staff_only
            else (scrim.public_channel_id, scrim.staff_channel_id)
        )
    ]
    return matches[0] if len(matches) == 1 else None


async def require_channel_scrim(
    ctx: commands.Context, *, staff_only: bool = False
) -> Scrim | None:
    scrim = resolve_channel_scrim(ctx, staff_only=staff_only)
    if scrim is None:
        where = "configured staff channel" if staff_only else "configured scrim channel"
        await send_private_command_feedback(
            ctx,
            f"This command must be used in a {where}. "
            "Use `!slots Scrim Name` to select a board explicitly.",
            silent=True,
        )
    return scrim


class DurableView(discord.ui.View):
    async def on_error(self, interaction, error, item):
        logger.error("Interaction error", exc_info=error)
        text = (
            "Your action could not be saved. Please check the board and try again."
            if isinstance(error, SlotStorageError)
            else "Something went wrong. Please check the board before trying again."
        )
        if interaction.response.is_done():
            await interaction.followup.send(text, ephemeral=True)
        else:
            await interaction.response.send_message(text, ephemeral=True)


def interaction_matches_scrim(
    interaction: discord.Interaction, scrim: Scrim, *, staff: bool = False
) -> bool:
    if (
        not is_active(scrim)
        or interaction.guild is None
        or interaction.guild.id != scrim.guild_id
        or interaction.message is None
    ):
        return False
    if staff:
        return interaction.channel_id == scrim.staff_channel_id
    return (
        interaction.channel_id == scrim.public_channel_id
        and scrim.public_message_id is not None
        and interaction.message.id == scrim.public_message_id
    )


def interaction_in_public_channel(
    interaction: discord.Interaction, scrim: Scrim, board_message_id: int
) -> bool:
    """Validate follow-up ephemeral interactions without treating them as boards."""
    return (
        is_active(scrim)
        and interaction.guild is not None
        and interaction.guild.id == scrim.guild_id
        and interaction.channel_id == scrim.public_channel_id
        and scrim.public_message_id == board_message_id
    )


async def refresh_staff_slots_locked(
    scrim: Scrim, *, create: bool = False
) -> bool:
    if not is_active(scrim):
        return False
    try:
        channel = await configured_text_channel(scrim, scrim.staff_channel_id)
        if channel is None or not is_active(scrim):
            return False
        message = scrim.runtime_staff_message
        if message is None and scrim.staff_message_id is not None:
            try:
                message = await channel.fetch_message(scrim.staff_message_id)
            except discord.NotFound:
                message = None
        if message is None:
            if not create and scrim.staff_message_id is None:
                return False
            message = await channel.send(
                content=build_staff_slots_message(scrim),
                allowed_mentions=discord.AllowedMentions.none(),
            )
            if not is_active(scrim):
                return False
            if type(getattr(message, "id", None)) is not int:
                logger.error("Staff channel returned an invalid message reference.")
                return False
            with repository.transaction():
                if not is_active(scrim):
                    return False
                scrim.staff_message_id = message.id
            scrim.runtime_staff_message = message
            return True
        if not is_active(scrim):
            return False
        try:
            await message.edit(
                content=build_staff_slots_message(scrim),
                embed=None,
                view=None,
            )
        except discord.NotFound:
            if not is_active(scrim):
                return False
            message = await channel.send(
                content=build_staff_slots_message(scrim),
                allowed_mentions=discord.AllowedMentions.none(),
            )
            if not is_active(scrim):
                return False
            if type(getattr(message, "id", None)) is not int:
                logger.error("Staff channel returned an invalid message reference.")
                return False
            with repository.transaction():
                if not is_active(scrim):
                    return False
                scrim.staff_message_id = message.id
        if not is_active(scrim):
            return False
        scrim.runtime_staff_message = message
        return True
    except (discord.HTTPException, AttributeError):
        logger.exception("Staff mirror for scrim %s is inaccessible.", scrim.id)
        return False


async def refresh_public_slots(scrim: Scrim) -> bool:
    async with scrim.board_lock:
        return await refresh_public_slots_locked(scrim)


async def refresh_public_slots_locked(scrim: Scrim, *, create: bool = False) -> bool:
    if not is_active(scrim):
        return False
    try:
        channel = await configured_text_channel(scrim, scrim.public_channel_id)
        if channel is None or not is_active(scrim):
            return False
        message = scrim.runtime_message
        if message is None and scrim.public_message_id is not None:
            try:
                message = await channel.fetch_message(scrim.public_message_id)
            except discord.NotFound:
                message = None
        if message is None:
            if not create and scrim.public_message_id is None:
                return False
            if not is_active(scrim):
                return False
            message = await channel.send(
                content=build_slots_message(scrim), view=ManagerSlotView(scrim)
            )
            if not is_active(scrim):
                try:
                    await message.delete()
                except discord.HTTPException:
                    pass
                return False
            with repository.transaction():
                if not is_active(scrim):
                    return False
                scrim.public_message_id = message.id
            scrim.runtime_message = message
            try:
                await refresh_staff_slots_locked(scrim, create=True)
            except SlotStorageError:
                logger.exception("Could not persist the staff mirror reference.")
            return True
        if not is_active(scrim) or message.id != scrim.public_message_id:
            return False
        try:
            await message.edit(
                content=build_slots_message(scrim),
                embed=None,
                view=ManagerSlotView(scrim),
            )
        except discord.NotFound:
            if not is_active(scrim):
                return False
            message = await channel.send(
                content=build_slots_message(scrim), view=ManagerSlotView(scrim)
            )
            if not is_active(scrim):
                try:
                    await message.delete()
                except discord.HTTPException:
                    pass
                return False
            with repository.transaction():
                if not is_active(scrim):
                    return False
                scrim.public_message_id = message.id
        if not is_active(scrim) or message.id != scrim.public_message_id:
            return False
        scrim.runtime_message = message
        try:
            await refresh_staff_slots_locked(scrim, create=True)
        except SlotStorageError:
            logger.exception("Could not persist the staff mirror reference.")
        return True
    except (discord.HTTPException, AttributeError):
        logger.exception("Scrim board %s is inaccessible.", scrim.id)
        return False


async def publish_scrim(scrim: Scrim) -> bool:
    """Recover, refresh, or create the configured board for one active scrim."""
    async with scrim.board_lock:
        return await refresh_public_slots_locked(scrim, create=True)


async def staff_channel(scrim: Scrim):
    try:
        channel = await configured_text_channel(scrim, scrim.staff_channel_id)
        return channel if channel is not None and is_active(scrim) else None
    except discord.HTTPException:
        logger.exception("Staff channel is inaccessible for scrim %s.", scrim.id)
        return None


async def send_scrim_log(
    scrim: Scrim,
    action: str,
    details: str,
) -> bool:
    """Send an immutable, timestamped audit entry to the configured logs channel."""
    config = repository.get_server_config(scrim.guild_id)
    logs_channel_id = (
        config.logs_channel_id
        if config is not None
        else scrim.logs_channel_id
    )
    if logs_channel_id is None:
        return False
    try:
        channel = await configured_text_channel(scrim, logs_channel_id)
    except discord.HTTPException:
        logger.exception("Could not resolve scrim logs channel (%s).", scrim.id)
        return False
    if channel is None:
        return False
    timestamp = discord.utils.utcnow().astimezone(timezone.utc).strftime(
        "%Y-%m-%d %H:%M:%S UTC"
    )
    try:
        await channel.send(
            f"**[{timestamp}] {action} — {discord.utils.escape_markdown(scrim.name)}**\n"
            f"{details}",
            allowed_mentions=discord.AllowedMentions.none(),
        )
        return True
    except discord.HTTPException:
        logger.exception("Could not write scrim log (%s).", scrim.id)
        return False


async def send_history_snapshot(scrim: Scrim, reason: str) -> bool:
    """Append the latest slot state to the configured Scrims History channel."""
    if scrim.history_channel_id is None:
        return False
    try:
        channel = await configured_text_channel(scrim, scrim.history_channel_id)
    except discord.HTTPException:
        logger.exception("Could not resolve scrim history channel (%s).", scrim.id)
        return False
    if channel is None:
        return False
    timestamp = discord.utils.utcnow().astimezone(timezone.utc).strftime(
        "%Y-%m-%d %H:%M:%S UTC"
    )
    try:
        await channel.send(
            f"**Scrims History — {discord.utils.escape_markdown(scrim.name)}**\n"
            f"Archived at {timestamp} · {discord.utils.escape_markdown(reason)}\n\n"
            f"{build_slots_message(scrim)}",
            allowed_mentions=discord.AllowedMentions.none(),
        )
        return True
    except discord.HTTPException:
        logger.exception("Could not archive scrim state (%s).", scrim.id)
        return False


async def grant_manager_access(scrim: Scrim, manager: discord.Member) -> bool:
    """Assign the Manager role and grant the captain temporary board access."""
    role_granted = True
    if scrim.manager_role_id is not None:
        guild = getattr(manager, "guild", None)
        get_role = getattr(guild, "get_role", None)
        role = get_role(scrim.manager_role_id) if get_role is not None else None
        if role is None or not hasattr(manager, "add_roles"):
            role_granted = False
        else:
            try:
                await manager.add_roles(
                    role, reason=f"Scrim manager assignment for {scrim.name}"
                )
            except discord.HTTPException:
                logger.exception("Could not assign manager role (%s).", scrim.id)
                role_granted = False
    try:
        channel = await configured_text_channel(scrim, scrim.public_channel_id)
    except discord.HTTPException:
        logger.exception("Could not resolve public scrim channel (%s).", scrim.id)
        return False
    if channel is None or not hasattr(channel, "set_permissions"):
        return False
    try:
        await channel.set_permissions(
            manager,
            view_channel=True,
            read_message_history=True,
            send_messages=False,
            reason=f"Scrim manager access for {scrim.name}",
        )
        return role_granted
    except discord.HTTPException:
        logger.exception("Could not grant manager access (%s).", scrim.id)
        return False


def manager_has_active_assignment(scrim: Scrim, manager_id: int) -> bool:
    return any(
        slot.manager_id == manager_id and not slot_is_assignable(slot)
        for slot in scrim.slots.values()
    )


async def revoke_manager_access(
    scrim: Scrim,
    manager_id: int,
    *,
    member: discord.Member | None = None,
) -> bool:
    """Remove the captain's Manager role and temporary board overwrite."""
    try:
        channel = await configured_text_channel(scrim, scrim.public_channel_id)
    except discord.HTTPException:
        logger.exception("Could not resolve public scrim channel (%s).", scrim.id)
        return False
    if channel is None or not hasattr(channel, "set_permissions"):
        return False
    if member is None:
        guild = getattr(channel, "guild", None)
        if guild is None:
            return False
        get_member = getattr(guild, "get_member", None)
        member = get_member(manager_id) if get_member is not None else None
        if member is None:
            try:
                fetch_member = getattr(guild, "fetch_member", None)
                if fetch_member is None:
                    return False
                member = await fetch_member(manager_id)
            except (discord.NotFound, discord.Forbidden, discord.HTTPException):
                logger.info(
                    "Manager %s is no longer resolvable in scrim %s.",
                    manager_id,
                    scrim.id,
                )
                return False
    role_removed = True
    if scrim.manager_role_id is not None:
        guild = getattr(member, "guild", None) or getattr(channel, "guild", None)
        get_role = getattr(guild, "get_role", None)
        role = get_role(scrim.manager_role_id) if get_role is not None else None
        if role is None or not hasattr(member, "remove_roles"):
            role_removed = False
        else:
            try:
                await member.remove_roles(
                    role, reason=f"Remove released scrim Manager role for {scrim.name}"
                )
            except discord.HTTPException:
                logger.exception("Could not remove manager role (%s).", scrim.id)
                role_removed = False
    try:
        await channel.set_permissions(
            member,
            overwrite=None,
            reason=f"Remove released scrim manager access for {scrim.name}",
        )
        return role_removed
    except discord.HTTPException:
        logger.exception("Could not revoke manager access (%s).", scrim.id)
        return False


async def revoke_manager_access_if_unused(
    scrim: Scrim,
    manager_id: int | None,
    *,
    member: discord.Member | None = None,
) -> bool:
    if manager_id is None or manager_has_active_assignment(scrim, manager_id):
        return True
    return await revoke_manager_access(scrim, manager_id, member=member)


async def remove_public_controls(scrim: Scrim) -> bool:
    """Remove manager controls without replacing the board message."""
    try:
        channel = await configured_text_channel(scrim, scrim.public_channel_id)
        if channel is None:
            return False
        message = scrim.runtime_message
        if message is None and scrim.public_message_id is not None:
            try:
                message = await channel.fetch_message(scrim.public_message_id)
            except discord.NotFound:
                return False
        if message is None:
            return False
        clear_reactions = getattr(message, "clear_reactions", None)
        if clear_reactions is not None:
            await clear_reactions()
        await message.edit(view=None)
        return True
    except (discord.HTTPException, AttributeError):
        logger.exception("Could not remove public scrim controls (%s).", scrim.id)
        return False


class SlotReviewView(DurableView):
    def __init__(self, scrim: Scrim, slot: SlotSnapshot) -> None:
        super().__init__(timeout=None)
        self.scrim = scrim
        self.slot = slot
        self.add_item(StaffActionButton(scrim.id, slot.number, slot.assignment_id, True))
        self.add_item(StaffActionButton(scrim.id, slot.number, slot.assignment_id, False))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        member = interaction.user
        allowed = (
            interaction_matches_scrim(interaction, self.scrim, staff=True)
            and isinstance(member, discord.Member)
            and member_is_staff(member, self.scrim)
        )
        if not allowed:
            await interaction.response.send_message(
                "These buttons are for staff in the configured staff channel only.",
                ephemeral=True,
            )
        return allowed

    async def finish_review(self, interaction: discord.Interaction, confirm: bool) -> None:
        await interaction.response.defer(ephemeral=True)
        result: SlotSnapshot | None = None
        async with self.scrim.state_lock:
            if is_active(self.scrim):
                current = self.scrim.slots[self.slot.number]
                if (
                    current.assignment_id == self.slot.assignment_id
                    and current.team_name == self.slot.team_name
                    and current.manager_id == self.slot.manager_id
                    and current.status == STATUS_PENDING
                ):
                    with repository.transaction():
                        result = current.snapshot() if not confirm else None
                        if confirm:
                            current.status = STATUS_CONFIRMED
                            result = current.snapshot()
                        else:
                            result = cancel_slot(current)
                    if not confirm and result is not None:
                        await revoke_manager_access_if_unused(
                            self.scrim, result.manager_id
                        )
        if result is None:
            disable_view_items(self)
            await interaction.followup.send(
                "This request is no longer active or the slot was reassigned.",
                ephemeral=True,
            )
            await delete_staff_review_message(interaction)
        else:
            text = (
                f"🟢 Team **{result.team_name}** has been confirmed."
                if confirm
                else f"🔴 Team **{result.team_name}** has been released."
            )
            if not await refresh_public_slots(self.scrim):
                text += " The public board could not be updated."
            await send_scrim_log(
                self.scrim,
                "STAFF VALIDATION" if confirm else "STAFF RELEASE",
                f"Slot {result.number:02d} · team **{result.team_name}** · "
                f"result {slot_status_emoji(result)} {slot_status_label(result)}",
            )
            await send_history_snapshot(
                self.scrim,
                "staff validation" if confirm else "staff release",
            )
            await interaction.followup.send(text, ephemeral=True)
            await delete_staff_review_message(interaction)


async def delete_staff_review_message(interaction: discord.Interaction) -> bool:
    message = getattr(interaction, "message", None)
    delete = getattr(message, "delete", None)
    if delete is None:
        return False
    try:
        await delete()
        return True
    except (discord.NotFound, discord.Forbidden):
        return False
    except discord.HTTPException:
        logger.exception("Could not delete the processed staff review message.")
        return False


async def notify_staff_for_review(scrim: Scrim, slot: SlotSnapshot) -> bool:
    channel = await staff_channel(scrim)
    if channel is None or not is_active(scrim):
        return False
    try:
        await channel.send(
            f"**{slot.team_name}**\nconfirmed",
            view=SlotReviewView(scrim, slot),
            allowed_mentions=discord.AllowedMentions.none(),
        )
        return True
    except discord.HTTPException:
        logger.exception("Could not send the staff notification (%s).", scrim.id)
        return False


async def notify_staff_of_manager_action(
    scrim: Scrim, slot: SlotSnapshot, emoji: str, label: str
) -> bool:
    channel = await staff_channel(scrim)
    if channel is None or not is_active(scrim):
        return False
    status = "confirmed" if slot.status == STATUS_PENDING else "cancelled"
    try:
        await channel.send(
            f"**{slot.team_name}**\n{status}",
            view=SlotReviewView(scrim, slot) if slot.status == STATUS_PENDING else None,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        return True
    except discord.HTTPException:
        logger.exception("Could not log the manager action (%s).", scrim.id)
        return False


class ManagerSlotView(DurableView):
    def __init__(self, scrim: Scrim) -> None:
        super().__init__(timeout=None)
        self.scrim = scrim
        self.assignments = {
            slot.number: slot.snapshot() for slot in scrim.slots.values()
            if not slot_is_assignable(slot)
        }
        self.fingerprint = assignment_fingerprint(scrim)
        self.add_item(
            ManagerActionButton(scrim.id, self.fingerprint, True, enabled=scrim.is_open)
        )
        self.add_item(
            ManagerActionButton(scrim.id, self.fingerprint, False, enabled=scrim.is_open)
        )

    async def finish_manager_action(
        self,
        interaction: discord.Interaction,
        confirm: bool,
        assignment: SlotSnapshot | None = None,
        cancellation_confirmed: bool = False,
        expected_board_id: int | None = None,
    ) -> None:
        if not (
            interaction_matches_scrim(interaction, self.scrim)
            if assignment is None
            else (
                expected_board_id is not None
                and interaction_in_public_channel(
                    interaction, self.scrim, expected_board_id
                )
            )
        ):
            await interaction.response.send_message(
                "This action is not valid for this board.", ephemeral=True
            )
            return
        if not self.scrim.is_open:
            await interaction.response.send_message(
                "Manager interactions are currently closed. Please wait for staff to reopen this scrim.",
                ephemeral=True,
            )
            return
        candidates = [
            item for item in self.assignments.values()
            if item.manager_id == interaction.user.id
        ]
        if assignment is None and len(candidates) > 1:
            select = discord.ui.Select(
                placeholder="Choose your slot",
                options=[
                    discord.SelectOption(
                        label=f"{item.number:02d} — {item.team_name}"[:100],
                        value=str(item.number),
                    ) for item in candidates
                ],
            )
            view = DurableView(timeout=60)
            actor_id = interaction.user.id
            board_message_id = interaction.message.id

            async def selected(choice: discord.Interaction) -> None:
                if (
                    choice.user.id != actor_id
                    or not interaction_in_public_channel(
                        choice, self.scrim, board_message_id
                    )
                ):
                    await choice.response.send_message(
                        "This selection is no longer available.", ephemeral=True
                    )
                    return
                picked = next(x for x in candidates if str(x.number) == select.values[0])
                await self.finish_manager_action(
                    choice,
                    confirm,
                    picked,
                    expected_board_id=board_message_id,
                )

            select.callback = selected
            view.add_item(select)
            await interaction.response.send_message(
                "Choose the slot you want to manage:", view=view, ephemeral=True
            )
            return
        if assignment is None and not candidates:
            await interaction.response.send_message(
                "You have no assigned slot on this board.", ephemeral=True
            )
            return
        assignment = assignment or candidates[0]
        if not confirm and not cancellation_confirmed:
            async with self.scrim.state_lock:
                current = self.scrim.slots[assignment.number]
                valid = (
                    is_active(self.scrim)
                    and current.assignment_id == assignment.assignment_id
                    and current.manager_id == interaction.user.id
                    and not slot_is_assignable(current)
                )
            if not valid:
                await interaction.response.send_message(
                    "This slot is no longer assigned to you. Please use the current board.",
                    ephemeral=True,
                )
                return
            await interaction.response.send_message(
                f"Are you sure you want to cancel slot **{assignment.number:02d}** "
                f"for **{discord.utils.escape_markdown(assignment.team_name)}**?\n"
                "Your slot will be released immediately and may be assigned to another team.\n"
                "Choose within 60 seconds. No action will be taken if this request expires.",
                view=CancelConfirmationView(
                    self,
                    assignment,
                    expected_board_id or interaction.message.id,
                ),
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return
        await interaction.response.defer(ephemeral=True)
        result: SlotSnapshot | None = None
        async with self.scrim.state_lock:
            if is_active(self.scrim):
                current = self.scrim.slots[assignment.number]
                if (
                    current.assignment_id == assignment.assignment_id
                    and current.manager_id == interaction.user.id
                    and (current.status == STATUS_RESERVED if confirm else not slot_is_assignable(current))
                ):
                    with repository.transaction():
                        if confirm:
                            current.status = STATUS_PENDING
                            result = current.snapshot()
                        else:
                            result = cancel_slot(current)
                    if not confirm and result is not None:
                        await revoke_manager_access_if_unused(
                            self.scrim,
                            result.manager_id,
                            member=(
                                interaction.user
                                if isinstance(interaction.user, discord.Member)
                                else None
                            ),
                        )
        if result is None:
            await interaction.followup.send(
                "This request was already processed or the slot was reassigned. "
                "Please check the current board.",
                ephemeral=True,
            )
            return
        if confirm:
            emoji, label = "✅", "Confirmation"
            text = f"🟠 Slot **{result.number:02d}**: Pending — awaiting staff approval."
        else:
            emoji, label = "❌", "Cancellation / Decline"
            text = f"🔴 Slot **{result.number:02d}** has been cancelled and is available for staff reuse."
        updated, notified = await asyncio.gather(
            refresh_public_slots(self.scrim),
            notify_staff_of_manager_action(self.scrim, result, emoji, label),
        )
        if not updated:
            text += " The public board could not be updated."
        if not notified:
            text += " Staff could not be notified."
        await send_scrim_log(
            self.scrim,
            "MANAGER CONFIRMATION" if confirm else "🔴 MANAGER CANCELLATION",
            f"Slot {result.number:02d} · team **{result.team_name}** · "
            f"result {slot_status_emoji(result)} {slot_status_label(result)}",
        )
        if not confirm:
            await send_history_snapshot(self.scrim, "manager cancellation")
        await interaction.followup.send(text, ephemeral=True)


class CancelConfirmationView(DurableView):
    def __init__(
        self,
        manager_view: ManagerSlotView,
        assignment: SlotSnapshot,
        board_message_id: int,
    ):
        super().__init__(timeout=60)
        self.manager_view = manager_view
        self.scrim = manager_view.scrim
        self.assignment = assignment
        self.board_message_id = board_message_id
        self.completed = False

    async def interaction_check(self, interaction):
        allowed = (
            interaction.user.id == self.assignment.manager_id
            and interaction_in_public_channel(
                interaction, self.scrim, self.board_message_id
            )
        )
        if not allowed:
            await interaction.response.send_message(
                "Only the assigned manager can answer this active request.", ephemeral=True
            )
        return allowed

    async def on_timeout(self):
        self.completed = True
        disable_view_items(self)

    @discord.ui.button(label="Yes, cancel my slot", style=discord.ButtonStyle.danger)
    async def accept(self, interaction, button):
        if not await self.interaction_check(interaction):
            return
        if self.completed:
            await interaction.response.send_message(
                "This request is no longer active. Please use the current board.",
                ephemeral=True,
            )
            return
        self.completed = True
        await self.manager_view.finish_manager_action(
            interaction,
            False,
            self.assignment,
            cancellation_confirmed=True,
            expected_board_id=self.board_message_id,
        )
        disable_view_items(self)
        self.stop()
        await interaction.message.edit(view=self)

    @discord.ui.button(label="Keep my slot", style=discord.ButtonStyle.secondary)
    async def keep(self, interaction, button):
        if not await self.interaction_check(interaction):
            return
        if self.completed:
            await interaction.response.send_message(
                "This request was already processed.", ephemeral=True
            )
            return
        self.completed = True
        disable_view_items(self)
        self.stop()
        await interaction.response.edit_message(
            content="Cancellation dismissed. No changes were made to your slot.",
            view=self,
        )


class ManagerActionButton(
    discord.ui.DynamicItem[discord.ui.Button],
    template=r"slots:manager:(?P<scrim>[a-f0-9]{16}):(?P<action>confirm|cancel):(?P<generation>[a-f0-9]{24})",
):
    def __init__(
        self, scrim_id: str, generation: str, confirm: bool, *, enabled: bool = True
    ):
        self.scrim_id, self.generation, self.confirm = scrim_id, generation, confirm
        super().__init__(discord.ui.Button(
            label="Confirm" if confirm else "Cancel",
            style=discord.ButtonStyle.success if confirm else discord.ButtonStyle.danger,
            emoji="✅" if confirm else "❌",
            disabled=not enabled,
            custom_id=f"slots:manager:{scrim_id}:{'confirm' if confirm else 'cancel'}:{generation}",
        ))

    @classmethod
    async def from_custom_id(cls, interaction, item, match: re.Match):
        return cls(match["scrim"], match["generation"], match["action"] == "confirm")

    async def callback(self, interaction):
        scrim = repository.get(self.scrim_id)
        if scrim is None:
            await interaction.response.send_message(
                "This scrim no longer exists.", ephemeral=True
            )
            return
        view = ManagerSlotView(scrim)
        try:
            if not interaction_matches_scrim(interaction, scrim):
                await interaction.response.send_message(
                    "This button does not belong to this board.", ephemeral=True
                )
            elif self.generation != view.fingerprint:
                await interaction.response.send_message(
                    "This button has expired. Please use the updated board.", ephemeral=True
                )
            elif not scrim.is_open:
                await interaction.response.send_message(
                    "Manager interactions are currently closed. Please wait for staff to reopen this scrim.",
                    ephemeral=True,
                )
            else:
                await view.finish_manager_action(interaction, self.confirm)
        except Exception as error:
            await view.on_error(interaction, error, self)


async def perform_scrim_reset(scrim: Scrim, invoking_channel) -> str:
    """Reset one scrim after its confirmation has already been authorized."""
    await clear_active_idpw(scrim.id)
    async with scrim.board_lock:
        if not is_active(scrim):
            return "This scrim no longer exists. Nothing was reset."
        async with scrim.state_lock:
            if not is_active(scrim):
                return "This scrim no longer exists. Nothing was reset."
            manager_ids = {
                slot.manager_id
                for slot in scrim.slots.values()
                if slot.manager_id is not None
            }
            with repository.transaction():
                for slot in scrim.slots.values():
                    slot.clear()
            for manager_id in manager_ids:
                await revoke_manager_access_if_unused(scrim, manager_id)
        await send_scrim_log(scrim, "SCRIM RESET", "All slots were reset by staff.")
        await send_history_snapshot(scrim, "scrim reset")
        if not is_active(scrim):
            return "This scrim no longer exists. The reset was stopped."

        channels_to_clear = []
        for channel_id in (scrim.staff_channel_id, scrim.public_channel_id):
            channel = (
                invoking_channel
                if invoking_channel is not None and invoking_channel.id == channel_id
                else None
            )
            if channel is None:
                try:
                    channel = await configured_text_channel(scrim, channel_id)
                except discord.HTTPException:
                    logger.exception(
                        "Could not resolve scrim channel (%s, %s).",
                        scrim.id,
                        channel_id,
                    )
            if channel is not None and all(
                existing.id != channel.id for existing in channels_to_clear
            ):
                channels_to_clear.append(channel)

        channel_clear_results = {}
        for channel in channels_to_clear:
            if not is_active(scrim):
                return "This scrim no longer exists. The reset was stopped."
            channel_clear_results[channel.id] = await purge_channel_messages(channel)

        public_cleared = channel_clear_results.get(scrim.public_channel_id, False)
        if public_cleared:
            scrim.runtime_message = None
        staff_cleared = channel_clear_results.get(scrim.staff_channel_id, False)
        if staff_cleared:
            scrim.runtime_staff_message = None

        updated = await refresh_public_slots_locked(scrim, create=True)
        if not is_active(scrim):
            return "This scrim no longer exists. The reset was stopped."

        channels_cleared = all(
            channel_clear_results.get(channel_id, False)
            for channel_id in (scrim.staff_channel_id, scrim.public_channel_id)
        )
        if updated and channels_cleared:
            return "✅ All slots are now available and both scrim channels were cleared."
        if updated:
            return (
                "✅ All slots are now available and the public board was updated, "
                "but one or more scrim channels could not be cleared."
            )
        return (
            "✅ All slots are now available, but the public board could not be updated. "
            "Please use `!slots` to refresh it."
        )


class ResetConfirmationView(DurableView):
    def __init__(self, scrim: Scrim, invoking_channel_id: int):
        super().__init__(timeout=60)
        self.scrim = scrim
        self.scrim_id = scrim.id
        self.guild_id = scrim.guild_id
        self.invoking_channel_id = invoking_channel_id
        self.message = None
        self.completed = False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        current = repository.get(self.scrim_id)
        allowed = (
            current is self.scrim
            and is_active(self.scrim)
            and interaction.guild is not None
            and interaction.guild.id == self.guild_id
            and interaction.channel_id == self.invoking_channel_id
            and interaction.message is not None
            and (
                self.message is None
                or interaction.message.id == self.message.id
            )
            and member_is_staff(interaction.user, self.scrim)
        )
        if not allowed:
            text = (
                "Only an authorized Staff member can confirm this reset "
                "in the original scrim channel."
            )
            try:
                if interaction.response.is_done():
                    await interaction.followup.send(text, ephemeral=True)
                else:
                    await interaction.response.send_message(text, ephemeral=True)
            except discord.HTTPException:
                logger.exception("Could not reject an invalid reset confirmation.")
        return allowed

    async def on_timeout(self) -> None:
        if self.completed:
            return
        self.completed = True
        disable_view_items(self)
        self.stop()
        if self.message is not None:
            try:
                await self.message.edit(
                    content="Reset confirmation expired. No slots were changed.",
                    view=self,
                )
            except discord.HTTPException:
                pass

    @discord.ui.button(
        label="Confirm Reset",
        emoji="⚠️",
        style=discord.ButtonStyle.danger,
    )
    async def confirm_reset(self, interaction: discord.Interaction, button) -> None:
        if not await self.interaction_check(interaction):
            return
        if self.completed:
            await interaction.response.send_message(
                "This reset confirmation is no longer active.", ephemeral=True
            )
            return
        self.completed = True
        disable_view_items(self)
        self.stop()
        await interaction.response.defer()
        result = await perform_scrim_reset(self.scrim, interaction.channel)
        if self.message is not None:
            try:
                await self.message.edit(content=result, view=self)
            except discord.NotFound:
                # Reset purges the invoking channel, so the confirmation message
                # may have been deleted before the result can be written to it.
                try:
                    await interaction.followup.send(result, ephemeral=True)
                except discord.HTTPException:
                    logger.exception("Could not send the reset result privately.")
            except discord.HTTPException:
                logger.exception("Could not update the reset confirmation message.")

    @discord.ui.button(
        label="Cancel",
        emoji="❌",
        style=discord.ButtonStyle.secondary,
    )
    async def cancel_reset(self, interaction: discord.Interaction, button) -> None:
        if not await self.interaction_check(interaction):
            return
        if self.completed:
            await interaction.response.send_message(
                "This reset confirmation is no longer active.", ephemeral=True
            )
            return
        self.completed = True
        disable_view_items(self)
        self.stop()
        await interaction.response.edit_message(
            content="Reset cancelled. No slots were changed.",
            view=self,
        )


@bot.command(name="reset")
@commands.guild_only()
async def reset_slots(ctx: commands.Context) -> None:
    scrim = await require_staff_scrim(ctx, allow_public=True)
    if scrim is None:
        return
    confirmation = ResetConfirmationView(scrim, ctx.channel.id)
    confirmation_message = await send_private_command_feedback(
        ctx,
        (
            f"⚠️ Reset **{discord.utils.escape_markdown(scrim.name)}**? "
            "This clears every slot and both configured scrim channels. "
            "Click **Confirm Reset** to continue."
        ),
        view=confirmation,
        delete_after=60,
    )
    confirmation.message = confirmation_message


@bot.command(name="open")
@commands.guild_only()
async def open_scrim(ctx: commands.Context) -> None:
    """Open manager interactions for the scrim configured in its public channel."""
    scrim = await require_staff_scrim(ctx, public_only=True)
    if scrim is None:
        return
    async with scrim.state_lock:
        if not is_active(scrim):
            await send_private_command_feedback(
                ctx, "This scrim no longer exists.", silent=True
            )
            return
        with repository.transaction():
            scrim.is_open = True
    await refresh_public_slots(scrim)
    await delete_command_message(ctx)
    await send_scrim_log(scrim, "SCRIM OPENED", "Manager interactions were opened.")


@bot.command(name="close")
@commands.guild_only()
async def close_scrim(ctx: commands.Context) -> None:
    """Close manager interactions for the scrim configured in its public channel."""
    scrim = await require_staff_scrim(ctx, public_only=True)
    if scrim is None:
        return
    async with scrim.state_lock:
        if not is_active(scrim):
            await send_private_command_feedback(
                ctx, "This scrim no longer exists.", silent=True
            )
            return
        with repository.transaction():
            scrim.is_open = False
    await remove_public_controls(scrim)
    await send_scrim_log(scrim, "SCRIM CLOSED", "Manager interactions were closed.")
    await send_history_snapshot(scrim, "scrim closed")
    await delete_command_message(ctx)


@bot.command(name="idpw")
@commands.guild_only()
async def distribute_idpw(ctx: commands.Context, lobby_id: str, minutes: int) -> None:
    """Publish the selected scrim's lobby ID/password and schedule its alerts."""
    scrim = await require_staff_scrim(ctx, allow_public=True)
    if scrim is None:
        return
    config = repository.get_idpw_config(scrim.id)
    if config is None:
        await send_private_command_feedback(
            ctx,
            "ID/password distribution is not configured. "
            "A member with the configured global Staff role must open `!setup`, "
            f"select **{discord.utils.escape_markdown(scrim.name)}**, and use **ID/PW** first.",
        )
        return
    if minutes < 1:
        await send_private_command_feedback(
            ctx, "The number of minutes must be at least 1."
        )
        return
    if scrim.manager_role_id is None:
        await send_private_command_feedback(
            ctx,
            "This scrim has no Manager role configured. Edit the scrim in `!setup` first.",
        )
        return

    target_channel = await configured_text_channel(scrim, config.target_channel_id)
    if target_channel is None:
        await send_private_command_feedback(
            ctx,
            "The configured ID/password channel could not be found or used.",
        )
        return

    await clear_active_idpw(scrim.id)
    start_timestamp = int(time.time()) + (minutes * 60)
    local_start = datetime.fromtimestamp(
        start_timestamp, tz=timezone_for_name(config.timezone_name)
    )
    heure_formatee = local_start.strftime("%H:%M")
    message_content = (
        f"<@&{scrim.manager_role_id}>\n"
        "```text\n"
        "Next Match\n\n"
        f"ID : {discord.utils.escape_markdown(lobby_id)}\n"
        f"PW : {discord.utils.escape_markdown(config.fixed_password)}\n"
        f"Start Time : {heure_formatee}\n"
        "```"
    )
    role_mentions = discord.AllowedMentions(
        everyone=False, users=False, roles=True, replied_user=False
    )
    try:
        message = await target_channel.send(
            content=message_content,
            allowed_mentions=role_mentions,
        )
        repository.set_idpw_announcement(scrim.id, message.id)
        active_idpw[scrim.id] = {"message": message, "tasks": []}
    except (discord.Forbidden, discord.HTTPException):
        logger.exception("Could not publish MATCH ACCESS for scrim %s.", scrim.id)
        await send_private_command_feedback(
            ctx,
            "The MATCH ACCESS message could not be sent to the configured channel.",
        )
        return

    async def schedule_alerts() -> None:
        try:
            if minutes > 3:
                await asyncio.sleep((minutes - 3) * 60)
                await target_channel.send(
                    f"<@&{scrim.manager_role_id}> "
                    "The match starts in 3 minutes. Please prepare.",
                    allowed_mentions=role_mentions,
                )
                await asyncio.sleep(2 * 60)
            elif minutes > 1:
                await asyncio.sleep((minutes - 1) * 60)
            if minutes >= 1:
                await target_channel.send(
                    f"<@&{scrim.manager_role_id}> "
                    "Final call. The match begins in 1 minute.",
                    allowed_mentions=role_mentions,
                )
        except asyncio.CancelledError:
            raise
        except (discord.Forbidden, discord.HTTPException):
            logger.exception("Could not send MATCH ACCESS alert.")

    task = bot.loop.create_task(schedule_alerts())
    active_idpw[scrim.id]["tasks"].append(task)
    await delete_command_message(ctx)


@bot.command(name="help")
async def help_command(ctx: commands.Context) -> None:
    await send_private_command_feedback(
        ctx,
        "**PUBG Mobile Scrim Slot Manager**\n"
        "`!slots [Full Scrim Name]` — publish or refresh a board\n"
        "`!add Team name / TAG / @Manager` — assign the first available slot (staff)\n"
        "`!remind` — remind managers with reserved slots to confirm or cancel\n"
        "Managers use `✅ Confirm` and `❌ Cancel` below their public board.\n"
        "Confirm → 🟠 Pending; only staff approval → 🟢 Confirmed.\n"
        "`!confirm <slot>` — force-confirm a slot (staff)\n"
        "`!remove <slot>` — force-remove a team from a slot (staff)\n"
        "`!reset` — make every slot available (staff)\n"
        "`!open` / `!close` — enable or disable manager actions in the public channel (staff)\n"
        "`!set <@Role>` — define the global scrims Staff role (server owner only)\n"
        "`!setup` — configure scrims and their channels (global scrims Staff role only)\n"
        "`!idpw <Lobby ID> <Minutes>` — publish match access details and alerts"
    )


@bot.event
async def on_command_error(ctx: commands.Context, error: commands.CommandError) -> None:
    original = getattr(error, "original", error)
    if isinstance(original, SlotStorageError):
        logger.error("Save error", exc_info=original)
        await send_private_command_feedback(
            ctx,
            "I could not save that change. Please try again.",
            silent=False,
        )
    elif isinstance(error, commands.MissingRequiredArgument):
        await send_private_command_feedback(
            ctx,
            "A required argument is missing. Use `!help` to check the command format.",
            silent=False,
        )
    elif isinstance(error, commands.BadArgument):
        await send_private_command_feedback(
            ctx,
            "One of the arguments is invalid. Use `!help` to check the command format.",
            silent=False,
        )
    elif isinstance(error, commands.MissingPermissions):
        await send_private_command_feedback(
            ctx,
            "You do not have permission to use this command.",
            silent=False,
        )
    elif isinstance(error, commands.NoPrivateMessage):
        await send_private_command_feedback(
            ctx,
            "This command can only be used inside a Discord server.",
            silent=False,
        )
    elif isinstance(error, commands.CommandNotFound):
        await delete_command_message(ctx)
    else:
        logger.exception("Command execution error", exc_info=error)
        await send_private_command_feedback(
            ctx,
            "The command could not be completed. Please try again.",
            silent=False,
        )


def install_setup_panel() -> None:
    global _setup_installed, _global_setup_installed
    import setup_panel
    import global_setup

    if not _setup_installed:
        setup_panel.install_setup(
            bot,
            repository,
            publish_scrim,
            log_action=send_scrim_log,
        )
        _setup_installed = True
    if not _global_setup_installed:
        global_setup.install_global_setup(bot, repository)
        _global_setup_installed = True


@bot.event
async def setup_hook() -> None:
    global _loaded
    if not _loaded:
        repository.load()
        _loaded = True
    install_setup_panel()
    bot.add_dynamic_items(ManagerActionButton, StaffActionButton)


async def migrate_legacy() -> None:
    if repository.legacy is None:
        return
    board = repository.legacy.get("public_board")
    if not isinstance(board, dict) or not board.get("channel_id"):
        logger.warning("Unclaimed v1 state: no resolvable public channel.")
        return
    try:
        channel = await get_channel(int(board["channel_id"]))
    except (discord.HTTPException, ValueError, TypeError):
        logger.exception("Retaining v1 state: public channel not found.")
        return
    guild = getattr(channel, "guild", None)
    if guild is None:
        logger.warning("Retaining v1 state: unable to determine the server.")
        return
    staff = None
    configured_id = os.getenv("STAFF_CHANNEL_ID", "").strip()
    if configured_id.isdigit():
        staff = guild.get_channel(int(configured_id))
    if staff is None:
        name = os.getenv("STAFF_CHANNEL_NAME", "staff").strip().lstrip("#")
        staff = discord.utils.get(guild.text_channels, name=name)
    if staff is None:
        logger.warning("Retaining v1 state: unable to resolve the staff channel.")
        return
    try:
        scrim = repository.claim_legacy(guild.id, staff.id)
        await publish_scrim(scrim)
        logger.info("Imported v1 state into scrim %s.", scrim.id)
    except Exception:
        logger.exception("v1 migration failed; state was retained.")


@bot.event
async def on_ready() -> None:
    if bot.user is not None:
        logger.info("Bot connected as %s (ID: %s)", bot.user, bot.user.id)
    await migrate_legacy()
    results = await asyncio.gather(
        *(publish_scrim(scrim) for scrim in list(repository.scrims.values())),
        return_exceptions=True,
    )
    for result in results:
        if isinstance(result, Exception):
            logger.error("Board recovery failed.", exc_info=result)


@bot.event
async def on_guild_join(guild: discord.Guild) -> None:
    """Welcome the server owner and point them to the global setup command."""
    owner = guild.owner
    if owner is None and guild.owner_id is not None:
        try:
            owner = await guild.fetch_member(guild.owner_id)
        except (discord.NotFound, discord.HTTPException):
            logger.warning("Could not resolve the owner of guild %s.", guild.id)
            return
    if owner is None:
        logger.warning("Guild %s has no resolvable owner.", guild.id)
        return
    try:
        await owner.send(
            f"Thanks for adding **{discord.utils.escape_markdown(guild.name)}'s "
            "PUBG Mobile Scrim Manager.\n\n"
            "To get started, go back to your server and type `!set @Staff`. "
            "The server owner must choose the global scrims Staff role before "
            "Staff members can use `!setup`."
        )
    except discord.Forbidden:
        logger.info("The owner of guild %s has disabled direct messages.", guild.id)
    except discord.HTTPException:
        logger.exception("Could not send the onboarding DM for guild %s.", guild.id)


@bot.command(name="slots", aliases=["publier_slots"])
@commands.guild_only()
async def show_slots(ctx: commands.Context, *, name: str | None = None) -> None:
    scrim = (
        resolve_named_scrim(ctx.guild.id, name) if name
        else resolve_channel_scrim(ctx)
    )
    if scrim is None:
        await send_private_command_feedback(
            ctx,
            "Scrim not found for this server and channel. "
            "Use `!slots Full Scrim Name` or configure one with `!setup`.",
            silent=True,
        )
        return
    if not member_is_staff(ctx.author, scrim):
        await send_private_command_feedback(
            ctx, "You must have the authorized staff role to publish this board.",
            silent=True,
        )
        return
    if await publish_scrim(scrim):
        await send_private_command_feedback(ctx, "The slot board has been updated.")


@bot.command(name="add")
@commands.guild_only()
async def add_team(ctx: commands.Context, *, arguments: str) -> None:
    scrim = await require_staff_scrim(ctx, allow_public=True)
    if scrim is None:
        return
    try:
        team_name, tag, manager_text = parse_add_arguments(arguments)
    except ValueError:
        await send_private_command_feedback(
            ctx,
            "Team name, tag and manager are required.\n"
            "Usage: `!add Team name / TAG / @Manager`",
            silent=True,
        )
        return
    try:
        manager = await commands.MemberConverter().convert(ctx, manager_text)
    except commands.MemberNotFound:
        await send_private_command_feedback(
            ctx, "Manager not found. Please mention a server member.",
            silent=True,
        )
        return
    assignment = None
    async with scrim.state_lock:
        if is_active(scrim):
            slot = next((x for x in scrim.slots.values() if slot_is_assignable(x)), None)
            if slot is not None:
                with repository.transaction():
                    slot.assignment_id += 1
                    slot.status, slot.team_name, slot.tag = STATUS_RESERVED, team_name, tag
                    slot.manager_id = manager.id
                assignment = slot.snapshot()
    if assignment is None:
        await send_private_command_feedback(
            ctx,
            f"All slots from {scrim.slot_start:02d} to {scrim.slot_end:02d} "
            "are already occupied.",
            silent=True,
        )
        return
    access_granted = await grant_manager_access(scrim, manager)
    await send_scrim_log(
        scrim,
        "TEAM ADDED",
        f"Slot {assignment.number:02d} · team **{assignment.team_name}** "
        f"· tag `{assignment.tag}` · manager <@{assignment.manager_id}>",
    )
    if not await refresh_public_slots(scrim):
        await send_private_command_feedback(
            ctx,
            "The slot was saved, but the board could not be updated. "
            "Use `!slots` to try again.",
            silent=True,
        )
        return
    if not access_granted:
        await send_private_command_feedback(
            ctx,
            f"Team **{assignment.team_name}** was added, but I could not grant "
            "the manager access to the slots channel.",
            silent=True,
        )
    await delete_command_message(ctx)


def parse_add_arguments(arguments: str) -> tuple[str, str, str]:
    """Parse both the historical slash format and the newer whitespace format."""
    raw = arguments.strip()
    if "/" in raw:
        parts = [part.strip() for part in raw.split("/", 2)]
        if len(parts) != 3 or not all(parts):
            raise ValueError("Expected Team / Tag / Manager.")
        return parts[0], parts[1], parts[2]

    parts = raw.split()
    if len(parts) < 3:
        raise ValueError("Expected Team name TAG @Manager.")
    team_name, tag, manager_text = (
        " ".join(parts[:-2]).strip(),
        parts[-2].strip(),
        parts[-1].strip(),
    )
    if not team_name or not tag or not manager_text:
        raise ValueError("Expected Team name TAG @Manager.")
    return team_name, tag, manager_text


@bot.command(name="remind")
@commands.guild_only()
async def remind_managers(ctx: commands.Context) -> None:
    """Mention managers whose assigned slots still need their confirmation."""
    scrim = await require_staff_scrim(ctx, allow_public=True)
    if scrim is None:
        return

    async with scrim.state_lock:
        reserved = [
            slot.snapshot()
            for slot in scrim.slots.values()
            if slot.status == STATUS_RESERVED and slot.manager_id is not None
        ]
        pending_count = sum(
            1 for slot in scrim.slots.values() if slot.status == STATUS_PENDING
        )

    if not reserved:
        pending_note = (
            f" {pending_count} Pending slot(s) are waiting for staff confirmation."
            if pending_count
            else ""
        )
        await ctx.send(
            "There are no Reserved slots waiting for a manager confirmation."
            + pending_note,
            allowed_mentions=discord.AllowedMentions.none(),
            delete_after=30,
        )
        await delete_command_message(ctx)
        return

    mentions = " ".join(f"<@{slot.manager_id}>" for slot in reserved)
    details = "\n".join(
        f"Slot **{slot.number:02d}** · **{slot.team_name}** (`{slot.tag}`)"
        for slot in reserved
    )
    try:
        await ctx.send(
            f"{mentions}\n"
            f"{details}\n"
            "Please Confirm / Cancel your Slot!",
            allowed_mentions=discord.AllowedMentions(users=True),
        )
    except discord.HTTPException:
        logger.exception("Could not send manager reminders (%s).", scrim.id)
    await delete_command_message(ctx)


@bot.command(name="confirm")
@commands.guild_only()
async def confirm_slot(ctx: commands.Context, slot_number: int) -> None:
    scrim = await require_staff_scrim(ctx)
    if scrim is None:
        return
    if slot_number not in scrim.slots:
        await send_private_command_feedback(ctx, "", silent=True)
        return
    confirmed = None
    async with scrim.state_lock:
        if not is_active(scrim):
            await send_private_command_feedback(ctx, "", silent=True)
            return
        slot = scrim.slots[slot_number]
        if slot_is_assignable(slot):
            await send_private_command_feedback(ctx, "", silent=True)
            return
        with repository.transaction():
            slot.status = STATUS_CONFIRMED
            confirmed = slot.snapshot()
    await refresh_public_slots(scrim)
    await send_scrim_log(
        scrim,
        "SLOT FORCE CONFIRMED",
        f"Slot {confirmed.number:02d} · team **{confirmed.team_name}**",
    )
    await send_history_snapshot(scrim, "staff forced slot confirmation")
    await delete_command_message(ctx)


@bot.command(name="remove")
@commands.guild_only()
async def remove_team(ctx: commands.Context, slot_number: int) -> None:
    scrim = await require_staff_scrim(ctx)
    if scrim is None:
        return
    if slot_number not in scrim.slots:
        await send_private_command_feedback(ctx, "", silent=True)
        return
    removed = None
    async with scrim.state_lock:
        if not is_active(scrim):
            await send_private_command_feedback(ctx, "", silent=True)
            return
        slot = scrim.slots[slot_number]
        if slot_is_assignable(slot):
            await send_private_command_feedback(ctx, "", silent=True)
            return
        removed = slot.snapshot()
        with repository.transaction():
            slot.clear()
        await revoke_manager_access_if_unused(scrim, removed.manager_id)
    if removed is None:
        return
    await refresh_public_slots(scrim)
    await send_scrim_log(
        scrim,
        "SLOT FORCE REMOVED",
        f"Slot {removed.number:02d} · team **{removed.team_name}**",
    )
    await send_history_snapshot(scrim, "staff forced slot removal")
    await delete_command_message(ctx)


class StaffActionButton(
    discord.ui.DynamicItem[discord.ui.Button],
    template=r"slots:staff:(?P<scrim>[a-f0-9]{16}):(?P<number>[0-9]{1,2}):(?P<assignment>[0-9]+):(?P<action>confirm|release)",
):
    def __init__(self, scrim_id: str, number: int, assignment_id: int, confirm: bool):
        self.scrim_id = scrim_id
        self.number, self.assignment_id, self.confirm = number, assignment_id, confirm
        super().__init__(discord.ui.Button(
            label="Confirm" if confirm else "Remove",
            style=discord.ButtonStyle.success if confirm else discord.ButtonStyle.danger,
            emoji="✅" if confirm else "❌",
            custom_id=f"slots:staff:{scrim_id}:{number}:{assignment_id}:"
                      f"{'confirm' if confirm else 'release'}",
        ))

    @classmethod
    async def from_custom_id(cls, interaction, item, match: re.Match):
        return cls(
            match["scrim"], int(match["number"]), int(match["assignment"]),
            match["action"] == "confirm",
        )

    async def callback(self, interaction):
        scrim = repository.get(self.scrim_id)
        if scrim is None or self.number not in scrim.slots:
            await interaction.response.send_message("Unknown scrim or slot.", ephemeral=True)
            return
        snapshot = scrim.slots[self.number].snapshot()
        view = SlotReviewView(scrim, snapshot)
        view.slot = SlotSnapshot(
            number=snapshot.number,
            status=snapshot.status,
            team_name=snapshot.team_name,
            tag=snapshot.tag,
            manager_id=snapshot.manager_id,
            assignment_id=self.assignment_id,
        )
        try:
            if await view.interaction_check(interaction):
                await view.finish_review(interaction, self.confirm)
        except Exception as error:
            await view.on_error(interaction, error, self)


install_setup_panel()


def main() -> None:
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        raise RuntimeError("The DISCORD_TOKEN environment variable is missing.")
    bot.run(token)


if __name__ == "__main__":
    main()