# Apex Scrims Manager — installation

Cette archive utilise une base SQLite persistante pour conserver les scrims,
les slots, les équipes, les statuts et les références des messages Discord.
Elle ne contient aucun token Discord.

## Installation

1. Décompresser l'archive sur l'hébergement.
2. Installer les dépendances :

```bash
python -m pip install -r requirements.txt
```

3. Ajouter une variable secrète nommée exactement `DISCORD_TOKEN`.
4. Définir la commande de démarrage :

```bash
python main.py
```

Ne place jamais le token directement dans `main.py`.

## Configuration Discord

Activer dans le portail développeur Discord :

- Message Content Intent
- Server Members Intent

Le bot doit avoir, dans les salons concernés :

- View Channel
- Send Messages
- Read Message History
- Manage Messages
- Manage Roles

Le rôle du bot doit être placé au-dessus des rôles qu'il doit gérer.

## Premier démarrage

1. Le propriétaire du serveur lance `!set @Staff`.
2. Les membres ayant le rôle Staff global lancent `!setup`.
3. Créer un scrim et sélectionner son rôle Manager et ses salons.
4. Créer un scrim et sélectionner :
   - le nom ;
   - le premier slot et le nombre de slots ;
   - le salon public ;
   - le salon staff mirror ;
   - les salons logs et historique.
5. Utiliser **Show/refresh slots** ou `!slots` pour publier le board.

Le board public affiche les slots numérotés, par défaut de `03` à `25`,
la légende des états et les boutons **Confirm** / **Cancel**. Le staff mirror
affiche la même liste sans les contrôles publics.

## Commandes principales

```text
!set @Staff
!setup
!slots [Nom du scrim]
!add Team name / TAG / @Manager
!remind
!confirm <slot>
!remove <slot>
!open
!close
!reset
!idpw <Lobby ID> <Minutes>
!help
```

`!reset` demande une confirmation, vide tous les slots, retire les accès
temporaires des managers, supprime l'annonce ID/PW et ses alertes pour ce
scrim, purge les deux salons configurés, puis recrée le board public et le
staff mirror avec tous les slots disponibles et aucune équipe.

Pour configurer ID/PW, ouvrir `!setup`, sélectionner le scrim, puis cliquer sur
**ID/PW**. Choisir le salon cible et définir le mot de passe. Le rôle Manager
est repris automatiquement du scrim sélectionné.

## Sauvegarde

La base est stockée dans `data/slots.sqlite3`. Conserver le dossier `data`
sur un disque persistant et ne lancer qu'une seule instance du bot avec cette
base. Le chemin peut être changé avec `SLOTS_DB_PATH`.

Ne pas versionner ni publier la base SQLite : elle contient des identifiants
Discord et l'état des équipes.