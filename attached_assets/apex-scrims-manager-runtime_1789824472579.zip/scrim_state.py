"""Persistent, guild-scoped scrim state. No Discord API calls in this module."""
from __future__ import annotations

import asyncio
import copy
import re
import secrets
import unicodedata
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from datetime import timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from slot_storage import SlotStateStore, SlotStorageError

DEFAULT_SLOT_START = 3
DEFAULT_SLOT_END = 25
MIN_SLOT_NUMBER = 1
MAX_SLOT_NUMBER = 99
MAX_SLOT_COUNT = 25
SLOT_NUMBERS = range(DEFAULT_SLOT_START, DEFAULT_SLOT_END + 1)
STATUS_AVAILABLE = "Disponible"
STATUS_RESERVED = "En attente du manager"
STATUS_PENDING = "En attente"
STATUS_CONFIRMED = "Confirmé"
STATUS_CANCELLED = "Annulé"
SLOT_STATUSES = (
    STATUS_AVAILABLE, STATUS_RESERVED, STATUS_PENDING,
    STATUS_CONFIRMED, STATUS_CANCELLED,
)
MAX_SCRIMS_PER_GUILD = 25
DEFAULT_IDPW_TIMEZONE = "UTC+01:00"
IDPW_TIMEZONE_CHOICES = tuple(
    [(f"UTC-{hour:02d}:00", f"UTC-{hour:02d}:00") for hour in range(12, 0, -1)]
    + [("UTC", "UTC")]
    + [(f"UTC+{hour:02d}:00", f"UTC+{hour:02d}:00") for hour in range(1, 13)]
)
_UNSET = object()


@dataclass(frozen=True)
class SlotSnapshot:
    number: int
    status: str
    team_name: str
    tag: str
    manager_id: int | None
    assignment_id: int


@dataclass
class Slot:
    number: int
    status: str = STATUS_AVAILABLE
    team_name: str = ""
    tag: str = ""
    manager_id: int | None = None
    assignment_id: int = 0

    def clear(self) -> None:
        self.assignment_id += 1
        self.status = STATUS_AVAILABLE
        self.team_name = ""
        self.tag = ""
        self.manager_id = None

    def snapshot(self) -> SlotSnapshot:
        return SlotSnapshot(**asdict(self))


def empty_slots(
    start: int = DEFAULT_SLOT_START,
    end: int = DEFAULT_SLOT_END,
) -> dict[int, Slot]:
    return {number: Slot(number) for number in range(start, end + 1)}


def validate_slot_range(start: int, end: int) -> tuple[int, int]:
    if (
        type(start) is not int
        or type(end) is not int
        or not MIN_SLOT_NUMBER <= start <= MAX_SLOT_NUMBER
        or not MIN_SLOT_NUMBER <= end <= MAX_SLOT_NUMBER
        or start > end
        or end - start + 1 > MAX_SLOT_COUNT
    ):
        if (
            type(start) is int
            and type(end) is int
            and start <= end
            and end - start + 1 > MAX_SLOT_COUNT
        ):
            raise ValueError(f"A scrim can have at most {MAX_SLOT_COUNT} slots.")
        raise ValueError(
            f"Slot range must be between {MIN_SLOT_NUMBER:02d} and "
            f"{MAX_SLOT_NUMBER:02d}, with the first slot no greater than the last."
        )
    return start, end


@dataclass
class Scrim:
    id: str
    guild_id: int
    name: str
    public_channel_id: int
    staff_channel_id: int
    staff_role_id: int | None = None
    manager_role_id: int | None = None
    logs_channel_id: int | None = None
    history_channel_id: int | None = None
    public_message_id: int | None = None
    staff_message_id: int | None = None
    is_open: bool = True
    slot_start: int = DEFAULT_SLOT_START
    slot_end: int = DEFAULT_SLOT_END
    slots: dict[int, Slot] = field(default_factory=empty_slots)
    # These references are process-local; only durable values are serialized.
    runtime_message: object | None = field(default=None, repr=False)
    runtime_staff_message: object | None = field(default=None, repr=False)
    state_lock: asyncio.Lock = field(default_factory=asyncio.Lock, repr=False)
    board_lock: asyncio.Lock = field(default_factory=asyncio.Lock, repr=False)
    deleted: bool = False

    def payload(self) -> dict:
        return {
            "id": self.id, "guild_id": self.guild_id, "name": self.name,
            "public_channel_id": self.public_channel_id,
            "staff_channel_id": self.staff_channel_id,
            "staff_role_id": self.staff_role_id,
            "manager_role_id": self.manager_role_id,
            "logs_channel_id": self.logs_channel_id,
            "history_channel_id": self.history_channel_id,
            "public_message_id": self.public_message_id,
            "staff_message_id": self.staff_message_id,
            "is_open": self.is_open,
            "slot_start": self.slot_start,
            "slot_end": self.slot_end,
            "slots": [asdict(slot) for slot in self.slots.values()],
        }


@dataclass
class ServerConfig:
    guild_id: int
    head_staff_role_id: int | None
    staff_role_id: int | None
    logs_channel_id: int | None

    def payload(self) -> dict:
        return {
            "guild_id": self.guild_id,
            "head_staff_role_id": self.head_staff_role_id,
            "staff_role_id": self.staff_role_id,
            "logs_channel_id": self.logs_channel_id,
        }


@dataclass(frozen=True)
class IdPwConfig:
    scrim_id: str
    target_channel_id: int
    fixed_password: str
    timezone_name: str = DEFAULT_IDPW_TIMEZONE
    announcement_message_id: int | None = None

    def payload(self) -> dict:
        return {
            "scrim_id": self.scrim_id,
            "target_channel_id": self.target_channel_id,
            "fixed_password": self.fixed_password,
            "timezone_name": self.timezone_name,
            "announcement_message_id": self.announcement_message_id,
        }


def _positive_id(value) -> bool:
    return type(value) is int and value > 0


def timezone_for_name(value: str):
    if value == "UTC":
        return timezone.utc
    match = re.fullmatch(r"UTC([+-])(\d{2}):(\d{2})", value)
    if match:
        hours = int(match.group(2))
        minutes = int(match.group(3))
        if hours > 14 or minutes > 59 or (hours == 14 and minutes):
            raise ValueError("Invalid UTC offset.")
        offset = timedelta(hours=hours, minutes=minutes)
        return timezone(offset if match.group(1) == "+" else -offset)
    return ZoneInfo(value)


def valid_timezone_name(value: object) -> bool:
    if not isinstance(value, str) or not value or len(value) > 100:
        return False
    try:
        timezone_for_name(value)
    except (ZoneInfoNotFoundError, ValueError):
        return False
    return True


def normalize_name(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("Scrim name must be text.")
    name = unicodedata.normalize("NFKC", value).strip()
    if not 1 <= len(name) <= 80 or any(unicodedata.category(c).startswith("C") for c in name):
        raise ValueError("Use a scrim name of 1–80 characters without control characters.")
    return name


def _read_slots(
    entries,
    slot_start: int = DEFAULT_SLOT_START,
    slot_end: int = DEFAULT_SLOT_END,
) -> dict[int, Slot]:
    validate_slot_range(slot_start, slot_end)
    if not isinstance(entries, list):
        raise ValueError("Invalid slot list.")
    result = [Slot(**entry) for entry in entries]
    expected_numbers = list(range(slot_start, slot_end + 1))
    if [slot.number for slot in result] != expected_numbers:
        raise ValueError(
            f"Slots must run from {slot_start:02d} to {slot_end:02d} in order."
        )
    for slot in result:
        if (
            type(slot.number) is not int
            or slot.status not in SLOT_STATUSES
            or type(slot.assignment_id) is not int or slot.assignment_id < 0
            or not isinstance(slot.team_name, str)
            or not isinstance(slot.tag, str)
            or (slot.manager_id is not None and not _positive_id(slot.manager_id))
            or (slot.status != STATUS_AVAILABLE and (
                not slot.team_name or not slot.tag or slot.manager_id is None
            ))
            or (slot.status == STATUS_AVAILABLE and (
                slot.team_name or slot.tag or slot.manager_id is not None
            ))
        ):
            raise ValueError("Invalid slot assignment.")
    return {slot.number: slot for slot in result}


def _legacy_payload(payload) -> dict:
    if not isinstance(payload, dict) or type(payload.get("version")) is not int or payload["version"] != 1:
        raise ValueError("Invalid legacy snapshot.")
    _read_slots(payload["slots"])
    board = payload["public_board"]
    if board is not None and (
        not isinstance(board, dict)
        or set(board) != {"channel_id", "message_id"}
        or not all(_positive_id(value) for value in board.values())
    ):
        raise ValueError("Invalid legacy board reference.")
    return copy.deepcopy(payload)


class ScrimRepository:
    """Atomic whole-repository snapshots, retaining old data until safely linked.

    transaction() must contain no awaits. Callers use per-scrim locks around
    asynchronous work and revalidate get(id) is the captured object.
    """

    def __init__(self, store: SlotStateStore):
        self.store = store
        self.scrims: dict[str, Scrim] = {}
        self.legacy: dict | None = None
        self.server_configs: dict[int, ServerConfig] = {}
        self.idpw_configs: dict[str, IdPwConfig] = {}

    def get(self, scrim_id: str) -> Scrim | None:
        scrim = self.scrims.get(scrim_id)
        return scrim if scrim is not None and not scrim.deleted else None

    def list(self, guild_id: int) -> list[Scrim]:
        return sorted(
            (s for s in self.scrims.values() if s.guild_id == guild_id and not s.deleted),
            key=lambda s: (s.name.casefold(), s.id),
        )

    def payload(self) -> dict:
        return {
            "version": 7,
            "scrims": [s.payload() for s in self.scrims.values()],
            "server_configs": [
                config.payload() for config in self.server_configs.values()
            ],
            "idpw_configs": [
                config.payload() for config in self.idpw_configs.values()
            ],
            "legacy": copy.deepcopy(self.legacy),
        }

    @staticmethod
    def _decode(
        payload: dict,
    ) -> tuple[
        dict[str, Scrim],
        dict | None,
        dict[int, ServerConfig],
            dict[str, IdPwConfig],
    ]:
        try:
            version = payload.get("version")
            if type(version) is not int or version not in (2, 3, 4, 5, 6, 7):
                raise ValueError("Unsupported snapshot version.")
            if not isinstance(payload["scrims"], list):
                raise ValueError("Invalid scrim list.")
            result: dict[str, Scrim] = {}
            names: set[tuple[int, str]] = set()
            channels: set[tuple[int, int]] = set()
            counts: dict[int, int] = {}
            for entry in payload["scrims"]:
                values = dict(entry)
                if payload["version"] == 2:
                    values.setdefault("staff_role_id", None)
                    values.setdefault("manager_role_id", None)
                    values.setdefault("logs_channel_id", None)
                    values.setdefault("history_channel_id", None)
                    values.setdefault("staff_message_id", None)
                    values.setdefault("is_open", True)
                if payload["version"] < 5:
                    values.setdefault("slot_start", DEFAULT_SLOT_START)
                    values.setdefault("slot_end", DEFAULT_SLOT_END)
                if payload["version"] < 7:
                    # The former per-scrim role was used for both concepts.
                    # Preserve it as the manager role; the server Staff role
                    # is copied into staff_role_id after configs are decoded.
                    values.setdefault("manager_role_id", values.get("staff_role_id"))
                values["slots"] = _read_slots(
                    values["slots"],
                    values["slot_start"],
                    values["slot_end"],
                )
                # Runtime-only fields must never be read from disk.
                if set(values) != {
                    "id", "guild_id", "name", "public_channel_id",
                    "staff_channel_id", "staff_role_id", "logs_channel_id",
                    "manager_role_id",
                    "history_channel_id", "public_message_id", "staff_message_id",
                    "is_open", "slot_start", "slot_end", "slots",
                }:
                    raise ValueError("Invalid scrim fields.")
                scrim = Scrim(**values)
                if (
                    not isinstance(scrim.id, str)
                    or not re.fullmatch(r"[a-f0-9]{16}", scrim.id)
                    or scrim.id in result
                    or not _positive_id(scrim.guild_id)
                    or not _positive_id(scrim.public_channel_id)
                    or not _positive_id(scrim.staff_channel_id)
                    or (
                        scrim.staff_role_id is not None
                        and not _positive_id(scrim.staff_role_id)
                    )
                    or (
                        scrim.manager_role_id is not None
                        and not _positive_id(scrim.manager_role_id)
                    )
                    or (
                        payload["version"] >= 7
                        and scrim.staff_role_id is not None
                        and scrim.manager_role_id is not None
                        and scrim.staff_role_id == scrim.manager_role_id
                    )
                    or (
                        scrim.logs_channel_id is not None
                        and not _positive_id(scrim.logs_channel_id)
                    )
                    or (
                        scrim.history_channel_id is not None
                        and not _positive_id(scrim.history_channel_id)
                    )
                    or (scrim.public_message_id is not None and not _positive_id(scrim.public_message_id))
                    or (scrim.staff_message_id is not None and not _positive_id(scrim.staff_message_id))
                    or type(scrim.is_open) is not bool
                    or validate_slot_range(scrim.slot_start, scrim.slot_end)
                    != (scrim.slot_start, scrim.slot_end)
                    or normalize_name(scrim.name) != scrim.name
                ):
                    raise ValueError("Invalid scrim identity or channel.")
                name_key = (scrim.guild_id, scrim.name.casefold())
                if name_key in names:
                    raise ValueError("Scrim names must be unique within a server.")
                names.add(name_key)
                configured_channels = (
                    scrim.public_channel_id,
                    scrim.staff_channel_id,
                    scrim.logs_channel_id,
                    scrim.history_channel_id,
                )
                for channel_id in filter(None, configured_channels):
                    channel_key = (scrim.guild_id, channel_id)
                    if channel_key in channels:
                        raise ValueError("Each scrim must have its own distinct public and staff channels.")
                    channels.add(channel_key)
                counts[scrim.guild_id] = counts.get(scrim.guild_id, 0) + 1
                if counts[scrim.guild_id] > MAX_SCRIMS_PER_GUILD:
                    raise ValueError("A server can have at most 25 scrims.")
                result[scrim.id] = scrim
            raw_configs = payload.get("server_configs", [])
            if not isinstance(raw_configs, list):
                raise ValueError("Invalid server configuration list.")
            configs: dict[int, ServerConfig] = {}
            for entry in raw_configs:
                if not isinstance(entry, dict) or set(entry) != {
                    "guild_id",
                    "head_staff_role_id",
                    "staff_role_id",
                    "logs_channel_id",
                }:
                    raise ValueError("Invalid server configuration fields.")
                config = ServerConfig(**entry)
                if (
                    not _positive_id(config.guild_id)
                    or (
                        config.head_staff_role_id is not None
                        and not _positive_id(config.head_staff_role_id)
                    )
                    or (
                        config.staff_role_id is not None
                        and not _positive_id(config.staff_role_id)
                    )
                    or (
                        config.logs_channel_id is not None
                        and not _positive_id(config.logs_channel_id)
                    )
                    or (
                        config.head_staff_role_id is not None
                        and config.head_staff_role_id == config.staff_role_id
                    )
                    or config.guild_id in configs
                ):
                    raise ValueError("Invalid server configuration.")
                configs[config.guild_id] = config
            if payload["version"] < 7:
                for scrim in result.values():
                    server_config = configs.get(scrim.guild_id)
                    if server_config is not None:
                        scrim.staff_role_id = server_config.staff_role_id
                    if scrim.staff_role_id == scrim.manager_role_id:
                        # The legacy snapshot cannot tell which one was
                        # intended. Preserve command permissions and require
                        # the Manager role to be selected explicitly.
                        scrim.manager_role_id = None
            raw_idpw_configs = payload.get("idpw_configs", [])
            if not isinstance(raw_idpw_configs, list):
                raise ValueError("Invalid ID/password configuration list.")
            idpw_configs: dict[str, IdPwConfig] = {}
            for entry in raw_idpw_configs:
                if payload["version"] < 6:
                    if not isinstance(entry, dict) or set(entry) != {
                        "guild_id",
                        "manager_role_id",
                        "target_channel_id",
                        "fixed_password",
                    }:
                        raise ValueError("Invalid ID/password configuration fields.")
                    guild_id = entry["guild_id"]
                    candidates = [
                        scrim for scrim in result.values()
                        if scrim.guild_id == guild_id
                    ]
                    # A former guild-wide configuration is safe to migrate only
                    # when that guild has exactly one scrim. With multiple scrims,
                    # the administrator must choose the target explicitly.
                    if len(candidates) != 1:
                        continue
                    config = IdPwConfig(
                        candidates[0].id,
                        entry["target_channel_id"],
                        entry["fixed_password"],
                    )
                else:
                    legacy_fields = {
                        "scrim_id",
                        "target_channel_id",
                        "fixed_password",
                        "announcement_message_id",
                    }
                    current_fields = legacy_fields | {"timezone_name"}
                    if (
                        not isinstance(entry, dict)
                        or set(entry) not in (legacy_fields, current_fields)
                    ):
                        raise ValueError("Invalid ID/password configuration fields.")
                    config_data = dict(entry)
                    config_data.setdefault("timezone_name", DEFAULT_IDPW_TIMEZONE)
                    config = IdPwConfig(**config_data)
                if (
                    not isinstance(config.scrim_id, str)
                    or config.scrim_id not in result
                    or not _positive_id(config.target_channel_id)
                    or not isinstance(config.fixed_password, str)
                    or not config.fixed_password.strip()
                    or len(config.fixed_password) > 100
                    or not valid_timezone_name(config.timezone_name)
                    or (
                        config.announcement_message_id is not None
                        and not _positive_id(config.announcement_message_id)
                    )
                    or config.scrim_id in idpw_configs
                ):
                    raise ValueError("Invalid ID/password configuration.")
                idpw_configs[config.scrim_id] = config
            legacy = payload.get("legacy")
            return (
                result,
                _legacy_payload(legacy) if legacy is not None else None,
                configs,
                idpw_configs,
            )
        except (KeyError, TypeError, ValueError) as error:
            raise SlotStorageError(
                f"Invalid scrim snapshot; existing data was not reset: {error}"
            ) from error

    def load(self) -> None:
        payload = self.store.load()
        if payload is None:
            self.store.save(self.payload())
            return
        if payload.get("version") == 1:
            try:
                legacy = _legacy_payload(payload)
            except (KeyError, TypeError, ValueError) as error:
                raise SlotStorageError("Invalid legacy snapshot; migration was stopped.") from error
            new_payload = {
                "version": 7,
                "scrims": [],
                "server_configs": [],
                "idpw_configs": [],
                "legacy": legacy,
            }
            self.store.save(new_payload)  # Preserve all v1 content before replacing runtime state.
            (
                self.scrims,
                self.legacy,
                self.server_configs,
                self.idpw_configs,
            ) = self._decode(new_payload)
            return
        restored, legacy, configs, idpw_configs = self._decode(payload)
        self.scrims, self.legacy, self.server_configs, self.idpw_configs = (
            restored,
            legacy,
            configs,
            idpw_configs,
        )
        if payload.get("version", 0) < 7:
            self.store.save(self.payload())

    @contextmanager
    def transaction(self):
        before = self.payload()
        objects = self.scrims.copy()
        config_objects = self.server_configs.copy()
        idpw_config_objects = self.idpw_configs.copy()
        try:
            yield
            payload = self.payload()
            self._decode(payload)
            self.store.save(payload)
        except Exception:
            restored, legacy, configs, idpw_configs = self._decode(before)
            for scrim_id, scrim in self.scrims.items():
                if scrim_id not in objects:
                    scrim.deleted = True
            for scrim_id, saved in restored.items():
                target = objects[scrim_id]
                for name in (
                    "guild_id",
                    "name",
                    "public_channel_id",
                    "staff_channel_id",
                    "staff_role_id",
                    "manager_role_id",
                    "logs_channel_id",
                    "history_channel_id",
                    "public_message_id",
                    "staff_message_id",
                    "is_open",
                    "slot_start",
                    "slot_end",
                ):
                    setattr(target, name, getattr(saved, name))
                target.slots = {
                    number: target.slots.get(number, Slot(number))
                    for number in saved.slots
                }
                for number, slot in saved.slots.items():
                    target.slots[number].__dict__.update(vars(slot))
                target.deleted = False
            self.scrims = objects
            self.legacy = legacy
            self.server_configs = config_objects
            self.idpw_configs = idpw_config_objects
            raise

    def get_server_config(self, guild_id: int) -> ServerConfig | None:
        return self.server_configs.get(guild_id)

    def save_server_config(
        self,
        guild_id: int,
        *,
        head_staff_role_id: int,
        staff_role_id: int,
        logs_channel_id: int,
    ) -> ServerConfig:
        config = ServerConfig(
            guild_id,
            head_staff_role_id,
            staff_role_id,
            logs_channel_id,
        )
        if (
            not _positive_id(guild_id)
            or not _positive_id(head_staff_role_id)
            or not _positive_id(staff_role_id)
            or not _positive_id(logs_channel_id)
            or head_staff_role_id == staff_role_id
        ):
            raise ValueError("Invalid server configuration.")
        with self.transaction():
            self.server_configs[guild_id] = config
        return config

    def save_scrims_staff_role(self, guild_id: int, staff_role_id: int) -> ServerConfig:
        """Persist the global role required for scrim administration commands."""
        if not _positive_id(guild_id) or not _positive_id(staff_role_id):
            raise ValueError("The scrims Staff role ID must be a positive integer.")
        current = self.get_server_config(guild_id)
        config = ServerConfig(
            guild_id,
            current.head_staff_role_id if current is not None else None,
            staff_role_id,
            current.logs_channel_id if current is not None else None,
        )
        with self.transaction():
            self.server_configs[guild_id] = config
        return config

    def get_idpw_config(self, scrim_id: str) -> IdPwConfig | None:
        return self.idpw_configs.get(scrim_id)

    def save_idpw_config(
        self,
        scrim_id: str,
        *,
        target_channel_id: int,
        fixed_password: str,
        timezone_name: str = DEFAULT_IDPW_TIMEZONE,
        announcement_message_id: int | None = None,
    ) -> IdPwConfig:
        scrim = self.get(scrim_id)
        if scrim is None:
            raise ValueError("This scrim does not exist.")
        config = IdPwConfig(
            scrim_id,
            target_channel_id,
            fixed_password,
            timezone_name,
            announcement_message_id,
        )
        if (
            not _positive_id(target_channel_id)
            or not isinstance(fixed_password, str)
            or not fixed_password.strip()
            or len(fixed_password) > 100
            or not valid_timezone_name(timezone_name)
            or (
                announcement_message_id is not None
                and not _positive_id(announcement_message_id)
            )
        ):
            raise ValueError("Invalid ID/password configuration.")
        with self.transaction():
            self.idpw_configs[scrim_id] = config
        return config

    def set_idpw_announcement(
        self, scrim_id: str, announcement_message_id: int | None
    ) -> IdPwConfig:
        current = self.get_idpw_config(scrim_id)
        if current is None:
            raise ValueError("This scrim has no ID/password configuration.")
        if (
            announcement_message_id is not None
            and not _positive_id(announcement_message_id)
        ):
            raise ValueError("Invalid ID/password announcement message.")
        updated = IdPwConfig(
            current.scrim_id,
            current.target_channel_id,
            current.fixed_password,
            current.timezone_name,
            announcement_message_id,
        )
        with self.transaction():
            self.idpw_configs[scrim_id] = updated
        return updated

    def _new_scrim(
        self,
        guild_id,
        name,
        public_channel_id,
        staff_channel_id,
        *,
        staff_role_id: int | None = None,
        manager_role_id: int | None = None,
        logs_channel_id: int | None = None,
        history_channel_id: int | None = None,
        is_open: bool = True,
        slot_start: int = DEFAULT_SLOT_START,
        slot_end: int = DEFAULT_SLOT_END,
    ) -> Scrim:
        name = normalize_name(name)
        validate_slot_range(slot_start, slot_end)
        if not all(_positive_id(value) for value in (guild_id, public_channel_id, staff_channel_id)):
            raise ValueError("Server and channel IDs must be positive integers.")
        if any(
            value is not None and not _positive_id(value)
            for value in (
                staff_role_id,
                manager_role_id,
                logs_channel_id,
                history_channel_id,
            )
        ):
            raise ValueError("Configured role and channel IDs must be positive integers.")
        if (
            staff_role_id is not None
            and manager_role_id is not None
            and staff_role_id == manager_role_id
        ):
            raise ValueError("Staff and Manager roles must be different.")
        configured_channels = tuple(
            value
            for value in (
                public_channel_id,
                staff_channel_id,
                logs_channel_id,
                history_channel_id,
            )
            if value is not None
        )
        if len(set(configured_channels)) != len(configured_channels):
            raise ValueError("Configured channels must be different.")
        if type(is_open) is not bool:
            raise ValueError("The scrim opening state must be boolean.")
        existing = self.list(guild_id)
        if len(existing) >= MAX_SCRIMS_PER_GUILD:
            raise ValueError("This server already has 25 scrims.")
        if any(s.name.casefold() == name.casefold() for s in existing):
            raise ValueError("A scrim with this name already exists on this server.")
        requested = set(configured_channels)
        if any(
            requested.intersection(
                set(
                    filter(
                        None,
                        (
                            s.public_channel_id,
                            s.staff_channel_id,
                            s.logs_channel_id,
                            s.history_channel_id,
                        ),
                    )
                )
            )
            for s in existing
        ):
            raise ValueError("One of these channels is already assigned to another scrim.")
        scrim_id = secrets.token_hex(8)
        while scrim_id in self.scrims:
            scrim_id = secrets.token_hex(8)
        return Scrim(
            scrim_id,
            guild_id,
            name,
            public_channel_id,
            staff_channel_id,
            staff_role_id=staff_role_id,
            manager_role_id=manager_role_id,
            logs_channel_id=logs_channel_id,
            history_channel_id=history_channel_id,
            is_open=is_open,
            slot_start=slot_start,
            slot_end=slot_end,
            slots=empty_slots(slot_start, slot_end),
        )

    def create(
        self,
        guild_id: int,
        name: str,
        public_channel_id: int,
        staff_channel_id: int,
        *,
        staff_role_id: int | None = None,
        manager_role_id: int | None = None,
        logs_channel_id: int | None = None,
        history_channel_id: int | None = None,
        is_open: bool = True,
        slot_start: int = DEFAULT_SLOT_START,
        slot_end: int = DEFAULT_SLOT_END,
    ) -> Scrim:
        # The caller validates that selected Discord channels belong to this guild.
        # Reusing the original public channel adopts rather than overwrites v1 data.
        if (
            self.legacy is not None
            and self.legacy["public_board"] is not None
            and self.legacy["public_board"]["channel_id"] == public_channel_id
        ):
            return self.claim_legacy(guild_id, staff_channel_id, name)
        scrim = self._new_scrim(
            guild_id,
            name,
            public_channel_id,
            staff_channel_id,
            staff_role_id=staff_role_id,
            manager_role_id=manager_role_id,
            logs_channel_id=logs_channel_id,
            history_channel_id=history_channel_id,
            is_open=is_open,
            slot_start=slot_start,
            slot_end=slot_end,
        )
        with self.transaction():
            self.scrims[scrim.id] = scrim
        return scrim

    def update_scrim(
        self,
        scrim_id: str,
        guild_id: int,
        *,
        name: str | object = _UNSET,
        public_channel_id: int | object = _UNSET,
        staff_channel_id: int | object = _UNSET,
        staff_role_id: int | None | object = _UNSET,
        manager_role_id: int | None | object = _UNSET,
        logs_channel_id: int | None | object = _UNSET,
        history_channel_id: int | None | object = _UNSET,
        slot_start: int | object = _UNSET,
        slot_end: int | object = _UNSET,
    ) -> Scrim:
        """Update selected scrim settings while preserving all other state."""
        scrim = self.get(scrim_id)
        if scrim is None or scrim.guild_id != guild_id:
            raise ValueError("This scrim does not exist on this server.")

        next_name = scrim.name if name is _UNSET else normalize_name(name)
        next_public = (
            scrim.public_channel_id
            if public_channel_id is _UNSET
            else public_channel_id
        )
        next_staff = (
            scrim.staff_channel_id
            if staff_channel_id is _UNSET
            else staff_channel_id
        )
        next_staff_role = (
            scrim.staff_role_id if staff_role_id is _UNSET else staff_role_id
        )
        next_manager_role = (
            scrim.manager_role_id
            if manager_role_id is _UNSET
            else manager_role_id
        )
        next_logs = (
            scrim.logs_channel_id
            if logs_channel_id is _UNSET
            else logs_channel_id
        )
        next_history = (
            scrim.history_channel_id
            if history_channel_id is _UNSET
            else history_channel_id
        )
        next_start = scrim.slot_start if slot_start is _UNSET else slot_start
        next_end = scrim.slot_end if slot_end is _UNSET else slot_end
        validate_slot_range(next_start, next_end)

        if not all(_positive_id(value) for value in (next_public, next_staff)):
            raise ValueError("Public and staff channel IDs must be positive integers.")
        if any(
            value is not None and not _positive_id(value)
            for value in (
                next_staff_role,
                next_manager_role,
                next_logs,
                next_history,
            )
        ):
            raise ValueError("Configured role and channel IDs must be positive integers.")
        if (
            next_staff_role is not None
            and next_manager_role is not None
            and next_staff_role == next_manager_role
        ):
            raise ValueError("Staff and Manager roles must be different.")
        configured_channels = tuple(
            value
            for value in (next_public, next_staff, next_logs, next_history)
            if value is not None
        )
        if len(set(configured_channels)) != len(configured_channels):
            raise ValueError("Configured channels must be different.")

        others = [other for other in self.list(guild_id) if other.id != scrim_id]
        if any(other.name.casefold() == next_name.casefold() for other in others):
            raise ValueError("A scrim with this name already exists on this server.")
        requested_channels = set(configured_channels)
        if any(
            requested_channels.intersection(
                set(
                    filter(
                        None,
                        (
                            other.public_channel_id,
                            other.staff_channel_id,
                            other.logs_channel_id,
                            other.history_channel_id,
                        ),
                    )
                )
            )
            for other in others
        ):
            raise ValueError("One of these channels is already assigned to another scrim.")

        with self.transaction():
            scrim.name = next_name
            scrim.public_channel_id = next_public
            scrim.staff_channel_id = next_staff
            scrim.staff_role_id = next_staff_role
            scrim.manager_role_id = next_manager_role
            scrim.logs_channel_id = next_logs
            scrim.history_channel_id = next_history
            if (next_start, next_end) != (scrim.slot_start, scrim.slot_end):
                occupied_outside = [
                    slot.number
                    for number, slot in scrim.slots.items()
                    if not next_start <= number <= next_end
                    and slot.status not in (STATUS_AVAILABLE, STATUS_CANCELLED)
                ]
                if occupied_outside:
                    numbers = ", ".join(f"{number:02d}" for number in occupied_outside)
                    raise ValueError(
                        f"Cannot shrink the range while slots {numbers} are occupied."
                    )
                scrim.slots = {
                    number: scrim.slots.get(number, Slot(number))
                    for number in range(next_start, next_end + 1)
                }
                scrim.slot_start = next_start
                scrim.slot_end = next_end
        return scrim

    def delete(self, scrim_id: str, guild_id: int) -> Scrim:
        scrim = self.get(scrim_id)
        if scrim is None or scrim.guild_id != guild_id:
            raise ValueError("This scrim does not exist on this server.")
        with self.transaction():
            del self.scrims[scrim_id]
            self.idpw_configs.pop(scrim_id, None)
            scrim.deleted = True
        return scrim

    def claim_legacy(self, guild_id: int, staff_channel_id: int, name="Imported Scrim") -> Scrim:
        if self.legacy is None or self.legacy["public_board"] is None:
            raise ValueError("No legacy board can be linked. Existing unlinked data is preserved.")
        board = self.legacy["public_board"]
        scrim = self._new_scrim(guild_id, name, board["channel_id"], staff_channel_id)
        scrim.slots = _read_slots(self.legacy["slots"])
        scrim.public_message_id = board["message_id"]
        with self.transaction():
            self.scrims[scrim.id] = scrim
            self.legacy = None
        return scrim